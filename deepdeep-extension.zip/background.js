import { streamChat, formatError } from './lib/api.js';
import { getSettings, isConfigured } from './lib/storage.js';

const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

async function fetchImageToDataUrl(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`fetch ${res.status}`);
  const blob = await res.blob();
  if (blob.size > MAX_IMAGE_BYTES) throw new Error('image too large');

  const bitmap = await createImageBitmap(blob);
  const maxEdge = 1024;
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const canvas = new OffscreenCanvas(Math.max(1, Math.round(bitmap.width * scale)), Math.max(1, Math.round(bitmap.height * scale)));
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const out = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.85 });
  return await blobToDataUrl(out);
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('read blob failed'));
    reader.readAsDataURL(blob);
  });
}

async function webSearch(query) {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query.slice(0, 500))}`;
  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) return '';
  const html = await res.text();
  const snippets = [...html.matchAll(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g)]
    .map((m) => m[1].replace(/<[^>]+>/g, '').trim())
    .filter(Boolean)
    .slice(0, 5);
  return snippets.join('\n\n');
}

chrome.runtime.onInstalled.addListener((details) => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

  chrome.contextMenus.create({
    id: 'send-page-to-sidepanel',
    title: '把当前页发送到 Deepdeep 侧边栏',
    contexts: ['page'],
  });

  chrome.contextMenus.create({
    id: 'dd-explain-selection',
    title: '用 Deepdeep 解释选中文字',
    contexts: ['selection'],
  });

  chrome.contextMenus.create({
    id: 'dd-translate-selection',
    title: '用 Deepdeep 翻译选中文字',
    contexts: ['selection'],
  });

  chrome.contextMenus.create({
    id: 'dd-summarize-selection',
    title: '用 Deepdeep 总结选中文字',
    contexts: ['selection'],
  });

  chrome.contextMenus.create({
    id: 'dd-view-image',
    title: '用 Deepdeep 查看图片',
    contexts: ['image'],
  });

  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'check-key') {
    isConfigured().then((result) => sendResponse({ hasKey: result }));
    return true;
  }
  if (msg.type === 'open-settings') {
    chrome.runtime.openOptionsPage();
  }
  if (msg.type === 'web-search') {
    webSearch(msg.query).then((text) => sendResponse({ text })).catch(() => sendResponse({ text: '' }));
    return true;
  }
  if (msg.type === 'fetch-image') {
    fetchImageToDataUrl(msg.url).then((dataUrl) => sendResponse({ dataUrl })).catch(() => sendResponse({ dataUrl: '' }));
    return true;
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'send-page-to-sidepanel' && tab?.windowId) {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => document.body.innerText.slice(0, 12000),
      });
      await chrome.storage.session.set({
        pendingPage: {
          text: result?.result || '',
          title: tab.title || '',
          url: tab.url || '',
        },
      });
    } catch {
      await chrome.storage.session.set({
        pendingPage: { text: '', title: tab.title || '', url: tab.url || '', error: true },
      });
    }
    return;
  }

  if (info.menuItemId === 'dd-view-image' && info.srcUrl && tab?.windowId) {
    await chrome.storage.session.set({
      pendingImage: { url: info.srcUrl, pageUrl: tab.url || '', title: tab.title || '' },
    });
    await chrome.sidePanel.open({ windowId: tab.windowId });
    return;
  }

  if (info.menuItemId.startsWith('dd-') && info.selectionText && tab?.windowId) {
    const action = info.menuItemId.replace('dd-', '').replace('-selection', '');
    await chrome.storage.session.set({
      pendingSelection: { text: info.selectionText, action },
    });
    await chrome.sidePanel.open({ windowId: tab.windowId });
  }
});

const activeControllers = new Map();

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'deepdeep-stream') return;

  port.onMessage.addListener(async (msg) => {
    if (msg.type === 'stream') {
      const controller = new AbortController();
      activeControllers.set(port, controller);
      try {
        const settings = await getSettings();
        for await (const chunk of streamChat(msg.messages, settings, { signal: controller.signal })) {
          port.postMessage({ type: 'chunk', text: chunk });
        }
        port.postMessage({ type: 'done' });
      } catch (err) {
        const formatted = formatError(err);
        if (formatted) port.postMessage({ type: 'error', message: formatted });
        else port.postMessage({ type: 'done' });
      } finally {
        activeControllers.delete(port);
      }
    } else if (msg.type === 'abort') {
      const controller = activeControllers.get(port);
      if (controller) controller.abort();
    }
  });

  port.onDisconnect.addListener(() => {
    const controller = activeControllers.get(port);
    if (controller) controller.abort();
    activeControllers.delete(port);
  });
});
