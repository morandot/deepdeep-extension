(function () {
  'use strict';

  if (window.marked) window.marked.setOptions({ breaks: true, gfm: true });

  let host = null;
  let shadow = null;
  let toolbar = null;
  let panel = null;
  let quoteEl = null;
  let messagesEl = null;
  let inputEl = null;
  let sendBtn = null;
  let stopBtn = null;
  let currentText = '';
  let savedRange = null;
  let selectedImageUrl = null;
  let conversation = [];
  let activePort = null;
  let isStreaming = false;
  let userScrolledUp = false;
  let searchEnabled = false;

  const ACTIONS = {
    explain: (t) => `请解释以下内容，通俗易懂地说明：\n\n${t}`,
    translate: (t, target) => `请将以下内容翻译成${target || '中文'}：\n\n${t}`,
    summarize: (t) => `请用简洁的要点总结以下内容：\n\n${t}`,
  };

  function getSelectedImage() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    if (sel.toString().trim()) return null;
    const range = sel.getRangeAt(0);
    let node = range.startContainer;
    if (node.nodeType === 3) node = node.parentElement;
    if (node && node.nodeType === 1) {
      const img = node.closest('img');
      if (img && img.src) return img;
    }
    const container = range.commonAncestorContainer;
    const host = container.nodeType === 1 ? container : container.parentElement;
    if (host) {
      const cr = range.getBoundingClientRect();
      const imgs = host.querySelectorAll('img');
      for (const img of imgs) {
        if (!img.src || !range.intersectsNode(img)) continue;
        const ir = img.getBoundingClientRect();
        if (ir.width <= 0 || ir.height <= 0) continue;
        const overlapX = Math.min(cr.right, ir.right) - Math.max(cr.left, ir.left);
        const overlapY = Math.min(cr.bottom, ir.bottom) - Math.max(cr.top, ir.top);
        if (overlapX > ir.width * 0.5 && overlapY > ir.height * 0.5) return img;
      }
    }
    return null;
  }

  async function getTranslateTarget() {
    const result = await chrome.storage.local.get('deepdeep_settings');
    return result['deepdeep_settings']?.translateTarget || '中文';
  }

  function sanitize(html) {
    if (window.DOMPurify) return window.DOMPurify.sanitize(html, { ALLOWED_TAGS: ['p','br','strong','em','code','pre','ul','ol','li','blockquote','a','table','thead','tbody','tr','th','td','h1','h2','h3','h4','h5','h6','del','sup','sub','hr'], ALLOWED_ATTR: ['href'] });
    const div = document.createElement('div');
    div.textContent = html;
    return div.innerHTML;
  }

  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function checkKeyAndProceed(callback) {
    chrome.runtime.sendMessage({ type: 'check-key' }, (response) => {
      if (response?.hasKey) {
        callback();
      } else {
        showNoKeyPanel();
      }
    });
  }

  function showNoKeyPanel() {
    ensureUI();
    panel.style.display = 'block';
    hideToolbar();
    positionPanel();
    messagesEl.innerHTML = `<div style="text-align:center;padding:20px 10px;color:var(--text-secondary);">
      <div style="margin-bottom:12px;">还未配置 API Key</div>
      <button class="dd-setup-btn" id="ddGoSettings">去设置</button>
    </div>`;
    quoteEl.style.display = 'none';
    shadow.getElementById('ddGoSettings').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'open-settings' });
    });
  }

  const STYLES = `
    :host {
      all: initial;
      --bg: #ffffff;
      --text: #1a1a1a;
      --text-secondary: #888;
      --border: #e8e8e8;
      --accent: #4D6BFE;
      --ai-bg: #f9f9f9;
      --user-bg: #4D6BFE;
      --user-text: #fff;
      --code-bg: rgba(0,0,0,0.06);
      --hover: rgba(0,0,0,0.04);
      --shadow: 0 4px 20px rgba(0,0,0,0.15);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    ::selection { background: #4D6BFE; color: #fff; }
    @media (prefers-color-scheme: dark) {
      :host {
        --bg: #0f0f0f; --text: #e8e8e8; --text-secondary: #777;
        --border: #2a2a2a; --accent: #6B83FE; --ai-bg: #1a1a1a;
        --user-bg: #6B83FE; --user-text: #fff;
        --code-bg: rgba(255,255,255,0.08); --hover: rgba(255,255,255,0.06);
        --shadow: 0 4px 20px rgba(0,0,0,0.5);
      }
      ::selection { background: #6B83FE; color: #fff; }
    }
    .dd-wrap {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      font-size: 13px; color: var(--text); position: fixed; z-index: 2147483647;
    }
    .dd-toolbar {
      display: flex; gap: 2px; background: var(--bg); border: 1px solid var(--border);
      border-radius: 9px; padding: 3px; box-shadow: var(--shadow);
    }
    .dd-toolbar button {
      background: none; border: none; color: var(--text); padding: 4px 9px;
      border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 500;
      white-space: nowrap; font-family: inherit; transition: background 0.12s;
    }
    .dd-toolbar button:hover { background: var(--ai-bg); }
    .dd-toolbar button.primary { color: var(--accent); font-weight: 600; }
    .dd-toolbar .sep { width: 1px; background: var(--border); margin: 4px 2px; }

    .dd-panel {
      width: 380px; max-width: calc(100vw - 32px); max-height: 500px;
      background: var(--bg); border: 1px solid var(--border); border-radius: 13px;
      box-shadow: var(--shadow); display: flex; flex-direction: column; overflow: hidden;
    }
    .dd-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 8px 12px; border-bottom: 1px solid var(--border); flex-shrink: 0;
    }
    .dd-title { font-weight: 700; font-size: 13px; display: flex; align-items: center; gap: 5px; }
    .dd-title svg { flex-shrink: 0; }
    .dd-close {
      background: none; border: none; cursor: pointer; width: 24px; height: 24px;
      font-size: 14px; color: var(--text); opacity: 0.4;
      border-radius: 5px; font-family: inherit;
      display: flex; align-items: center; justify-content: center;
    }
    .dd-close:hover { opacity: 1; background: var(--ai-bg); }

    .dd-quote {
      padding: 7px 12px; border-left: 3px solid var(--accent); background: var(--ai-bg);
      font-size: 11px; max-height: 64px; overflow-y: auto; white-space: pre-wrap;
      word-break: break-word; flex-shrink: 0; color: var(--text-secondary);
    }

    .dd-messages {
      flex: 1; overflow-y: auto; padding: 10px 12px; display: flex; flex-direction: column;
      gap: 7px; min-height: 46px;
    }
    .dd-messages::-webkit-scrollbar { width: 5px; }
    .dd-messages::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

    .dd-msg { max-width: 90%; padding: 7px 11px; border-radius: 11px; word-break: break-word; animation: dd-in 0.2s ease-out; }
    .dd-msg-user { align-self: flex-end; background: var(--user-bg); color: var(--user-text); border-bottom-right-radius: 3px; }
    .dd-img-thumb { display: block; max-width: 180px; max-height: 140px; border-radius: 8px; margin: 2px 0 4px; object-fit: cover; }
    .dd-msg-ai { align-self: flex-start; background: var(--ai-bg); border-bottom-left-radius: 3px; }
    .dd-msg-ai p { margin: 0 0 4px; }
    .dd-msg-ai p:last-child { margin: 0; }
    .dd-msg-ai code { background: var(--code-bg); padding: 1px 4px; border-radius: 3px; font-size: 11px; }
    .dd-msg-ai pre { background: var(--code-bg); padding: 7px 9px; border-radius: 7px; overflow-x: auto; margin: 4px 0; font-size: 11px; }
    .dd-msg-ai pre code { background: none; padding: 0; }
    .dd-msg-ai ul, .dd-msg-ai ol { padding-left: 16px; margin: 3px 0; }
    .dd-msg-ai blockquote { border-left: 2px solid var(--accent); padding-left: 8px; margin: 4px 0; color: var(--text-secondary); }
    .dd-error { color: #e53935; }

    .dd-msg-actions { display: flex; gap: 3px; opacity: 0; transition: opacity 0.12s; }
    .dd-msg-ai:hover .dd-msg-actions { opacity: 1; }
    .dd-msg-action { background: none; border: none; cursor: pointer; font-size: 10px; color: var(--text-secondary); padding: 1px 5px; border-radius: 3px; font-family: inherit; }
    .dd-msg-action:hover { background: var(--hover); color: var(--text); }

    @keyframes dd-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }

    .dd-typing { display: inline-flex; gap: 3px; }
    .dd-typing span { width: 5px; height: 5px; border-radius: 50%; background: currentColor; opacity: 0.4; animation: dd-bounce 1.2s infinite ease-in-out; }
    .dd-typing span:nth-child(2) { animation-delay: 0.15s; }
    .dd-typing span:nth-child(3) { animation-delay: 0.3s; }
    @keyframes dd-bounce { 0%,60%,100% { transform: scale(0.8); opacity: 0.4; } 30% { transform: scale(1.1); opacity: 1; } }

    .dd-input-row {
      display: flex; gap: 5px; padding: 7px 11px; border-top: 1px solid var(--border); flex-shrink: 0; align-items: center;
    }
    .dd-input-row input {
      flex: 1; padding: 6px 10px; border: 1px solid var(--border); border-radius: 8px;
      font-size: 12px; font-family: inherit; background: var(--bg); color: var(--text);
    }
    .dd-input-row input:focus { outline: none; border-color: var(--accent); }
    .dd-input-row input::placeholder { color: var(--text-secondary); }
    .dd-send-btn, .dd-stop-btn {
      width: 30px; height: 30px; border: none; border-radius: 8px; cursor: pointer;
      display: flex; align-items: center; justify-content: center; flex-shrink: 0;
      font-size: 13px; font-family: inherit;
    }
    .dd-send-btn { background: var(--accent); color: #fff; }
    .dd-send-btn:hover { opacity: 0.88; }
    .dd-stop-btn { background: #e53935; color: #fff; display: none; }
    .dd-stop-btn:hover { opacity: 0.88; }

    .dd-setup-btn {
      padding: 8px 24px; border: none; border-radius: 8px; background: var(--accent);
      color: #fff; font-size: 14px; font-weight: 600; cursor: pointer; font-family: inherit;
    }
    .dd-setup-btn:hover { opacity: 0.88; }

    .dd-suggestions { padding: 8px 0; }
    .dd-suggestions-hint { font-size: 12px; color: var(--text-secondary); margin-bottom: 8px; text-align: center; }
    .dd-suggestion-chips { display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; }
    .dd-suggestion-chip {
      display: flex; align-items: center; gap: 4px; padding: 5px 12px;
      border: 1px solid var(--border); border-radius: 14px; background: var(--bg);
      color: var(--text); font-size: 11px; font-weight: 500; cursor: pointer;
      font-family: inherit; transition: all 0.15s;
    }
    .dd-suggestion-chip:hover { border-color: var(--accent); color: var(--accent); background: rgba(77,107,254,0.06); }
    .dd-suggestion-chip:active { transform: scale(0.95); }
    .dd-retry-btn {
      display: inline-block; margin-top: 6px; padding: 3px 12px;
      border: 1px solid var(--border); border-radius: 8px;
      background: var(--bg); color: var(--text); font-size: 11px;
      font-family: inherit; cursor: pointer; transition: all 0.12s;
    }
    .dd-retry-btn:hover { border-color: var(--accent); color: var(--accent); }

    .dd-toolbar button.dd-tb-search { color: var(--text-secondary); padding: 5px 8px; }
    .dd-toolbar button.dd-tb-search:hover { background: var(--ai-bg); color: var(--text); }
    .dd-toolbar button.dd-tb-search.active { background: var(--accent); color: #fff; }

    .dd-search-toggle {
      width: 30px; height: 30px; border: 1px solid var(--border); border-radius: 8px;
      background: var(--bg); color: var(--text-secondary); cursor: pointer;
      display: flex; align-items: center; justify-content: center; flex-shrink: 0;
      transition: all 0.12s; padding: 0;
    }
    .dd-search-toggle:hover { color: var(--text); border-color: var(--accent); }
    .dd-search-toggle.active { background: var(--accent); color: #fff; border-color: var(--accent); }

    @media (pointer: coarse) {
      .dd-msg-actions { opacity: 1; }
      .dd-toolbar button { padding: 7px 12px; }
    }
  `;

  function ensureUI() {
    if (host) return;
    host = document.createElement('div');
    host.id = 'deepdeep-float-host';
    host.style.cssText = 'all:initial;position:static;';
    shadow = host.attachShadow({ mode: 'open' });

    toolbar = document.createElement('div');
    toolbar.className = 'dd-wrap';
    toolbar.style.display = 'none';
    toolbar.innerHTML = `
      <div class="dd-toolbar">
        <button class="primary tb-img" data-action="view-image" style="display:none" aria-label="查看图片">看图</button>
        <button class="primary tb-text" data-action="ask" aria-label="问 Deepdeep">问 Deepdeep</button>
        <div class="sep tb-text"></div>
        <button class="tb-text" data-action="explain" title="解释" aria-label="解释选中文字">解释</button>
        <button class="tb-text" data-action="translate" title="翻译" aria-label="翻译选中文字">翻译</button>
        <button class="tb-text" data-action="summarize" title="总结" aria-label="总结选中文字">总结</button>
        <div class="sep"></div>
        <button class="dd-tb-search" data-action="search-toggle" title="联网搜索" aria-label="切换联网搜索"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></button>
      </div>`;

    panel = document.createElement('div');
    panel.className = 'dd-wrap';
    panel.style.display = 'none';
    panel.innerHTML = `
      <div class="dd-panel">
        <div class="dd-header">
          <span class="dd-title"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="14" height="14" role="img" aria-label="deepdeep"><path fill="currentColor" fill-rule="evenodd" d="M0 64 A64 64 0 0 1 128 64 A64 64 0 0 1 0 64 Z M37 32 L61 32 C79 32 91 46 91 64 C91 82 79 96 61 96 L37 96 Z M51 46 L61 46 C71 46 77 54 77 64 C77 74 71 82 61 82 L51 82 Z"/></svg>Deepdeep</span>
          <button class="dd-close"><i class="icon-x"></i></button>
        </div>
        <div class="dd-quote"></div>
        <div class="dd-messages"></div>
        <div class="dd-input-row">
          <button class="dd-search-toggle" title="联网搜索" aria-label="切换联网搜索"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></button>
          <input type="text" placeholder="追问… (Enter 发送)">
          <button class="dd-send-btn"><i class="icon-send"></i></button>
          <button class="dd-stop-btn"><i class="icon-square"></i></button>
        </div>
      </div>`;

    const styleEl = document.createElement('style');
    styleEl.textContent = STYLES;
    shadow.appendChild(styleEl);

    const fontUrl = chrome.runtime.getURL('vendor/lucide/lucide.woff2');
    const lucideStyle = document.createElement('style');
    lucideStyle.textContent = `
      @font-face {
        font-family: "lucide";
        src: url('${fontUrl}') format('woff2');
        font-weight: normal; font-style: normal; font-display: block;
      }
      [class^="icon-"], [class*=" icon-"] {
        font-family: 'lucide' !important; font-size: inherit;
        font-style: normal; line-height: 1;
        -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;
      }
      .icon-send::before { content: "\\e152"; }
      .icon-square::before { content: "\\e167"; }
      .icon-x::before { content: "\\e1b2"; }
      .icon-copy::before { content: "\\e09e"; }
      .icon-check::before { content: "\\e06c"; }
    `;
    shadow.appendChild(lucideStyle);
    shadow.appendChild(toolbar);
    shadow.appendChild(panel);
    document.documentElement.appendChild(host);

    quoteEl = shadow.querySelector('.dd-quote');
    messagesEl = shadow.querySelector('.dd-messages');
    inputEl = shadow.querySelector('.dd-input-row input');
    sendBtn = shadow.querySelector('.dd-send-btn');
    stopBtn = shadow.querySelector('.dd-stop-btn');

    toolbar.addEventListener('mousedown', (e) => e.preventDefault());
    toolbar.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      if (btn.dataset.action === 'search-toggle') {
        searchEnabled = !searchEnabled;
        btn.classList.toggle('active', searchEnabled);
        const panelToggle = shadow.querySelector('.dd-search-toggle');
        if (panelToggle) panelToggle.classList.toggle('active', searchEnabled);
        return;
      }
      savedRange = saveSelection();
      checkKeyAndProceed(() => {
        const action = btn.dataset.action;
        showPanel();
        if (action === 'view-image') {
          streamImageRequest();
        } else if (action !== 'ask') {
          sendAction(action);
        }
      });
    });

    shadow.querySelector('.dd-close').addEventListener('click', closePanel);
    shadow.querySelector('.dd-search-toggle').addEventListener('click', (e) => {
      searchEnabled = !searchEnabled;
      e.currentTarget.classList.toggle('active', searchEnabled);
      const tbSearch = shadow.querySelector('.dd-tb-search');
      if (tbSearch) tbSearch.classList.toggle('active', searchEnabled);
    });
    sendBtn.addEventListener('click', () => { if (!isStreaming) sendFollowUp(); });
    stopBtn.addEventListener('click', stopStream);
    inputEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); if (!isStreaming) sendFollowUp(); }
    });

    messagesEl.addEventListener('scroll', () => {
      const atBottom = messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 30;
      userScrolledUp = !atBottom;
    });
  }

  function saveSelection() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    return sel.getRangeAt(0).cloneRange();
  }

  function getSelectionText() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return '';
    return sel.toString().trim();
  }

  function positionToolbar() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) {
      if (savedRange) {
        const rect = savedRange.getBoundingClientRect();
        applyToolbarPos(rect);
      }
      return;
    }
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    applyToolbarPos(rect);
  }

  function applyToolbarPos(rect) {
    const tbRect = toolbar.querySelector('.dd-toolbar').getBoundingClientRect();
    let top = rect.top - tbRect.height - 8 + window.scrollY;
    let left = rect.left + window.scrollX;
    const maxLeft = window.innerWidth + window.scrollX - tbRect.width - 8;
    if (left > maxLeft) left = maxLeft;
    if (left < 8) left = 8;
    toolbar.style.top = top + 'px';
    toolbar.style.left = left + 'px';
    if (top < window.scrollY) toolbar.style.top = (rect.bottom + 8 + window.scrollY) + 'px';
  }

  function positionPanel() {
    const sel = window.getSelection();
    let rect;
    if (sel && sel.rangeCount > 0) {
      rect = sel.getRangeAt(0).getBoundingClientRect();
    } else if (savedRange) {
      rect = savedRange.getBoundingClientRect();
    } else {
      rect = { left: window.innerWidth / 2, top: 80, right: window.innerWidth / 2, bottom: 80 };
    }
    const panelWidth = 400;
    const maxLeft = window.innerWidth + window.scrollX - panelWidth - 16;
    let left = rect.right + window.scrollX + 8;
    if (left > maxLeft) left = rect.left + window.scrollX - panelWidth - 8;
    if (left < 8) left = 8;
    let top = rect.top + window.scrollY;
    const panelH = Math.min(520, window.innerHeight - 32);
    if (top + panelH > window.scrollY + window.innerHeight - 8) top = window.scrollY + window.innerHeight - panelH - 8;
    if (top < window.scrollY + 8) top = window.scrollY + 8;
    panel.style.top = top + 'px';
    panel.style.left = left + 'px';
  }

  function showToolbar() {
    toolbar.querySelectorAll('.tb-img').forEach((b) => (b.style.display = 'none'));
    toolbar.querySelectorAll('.tb-text').forEach((b) => (b.style.display = ''));
    toolbar.style.display = 'block';
    positionToolbar();
  }
  function showImageToolbar() {
    toolbar.querySelectorAll('.tb-img').forEach((b) => (b.style.display = ''));
    toolbar.querySelectorAll('.tb-text').forEach((b) => (b.style.display = 'none'));
    toolbar.style.display = 'block';
    positionToolbar();
  }
  function hideToolbar() { toolbar.style.display = 'none'; }

  let panelOpenText = '';

  function showPanel() {
    ensureUI();
    if (panel.style.display === 'block' && panelOpenText === currentText && !selectedImageUrl) return;
    panel.style.display = 'block';
    hideToolbar();
    positionPanel();
    panelOpenText = currentText;
    conversation = [];
    messagesEl.innerHTML = '';
    quoteEl.textContent = currentText;
    quoteEl.style.display = currentText ? 'block' : 'none';
    userScrolledUp = false;
    if (selectedImageUrl) {
      messagesEl.innerHTML = `
        <div class="dd-suggestions">
          <div class="dd-suggestions-hint">🖼️ 将询问模型对这张图片的理解</div>
        </div>`;
    } else {
      renderSuggestions();
    }
    setTimeout(() => inputEl.focus(), 50);
  }

  function renderSuggestions() {
    messagesEl.innerHTML = `
      <div class="dd-suggestions">
        <div class="dd-suggestions-hint">你想对这个内容做什么？</div>
        <div class="dd-suggestion-chips">
          <button class="dd-suggestion-chip" data-action="explain">解释</button>
          <button class="dd-suggestion-chip" data-action="translate">翻译</button>
          <button class="dd-suggestion-chip" data-action="summarize">总结</button>
        </div>
      </div>`;
    messagesEl.querySelectorAll('.dd-suggestion-chip').forEach((chip) => {
      chip.addEventListener('click', () => sendAction(chip.dataset.action));
    });
  }

  function closePanel() {
    panel.style.display = 'none';
    panelOpenText = '';
    if (activePort) { activePort.disconnect(); activePort = null; }
    isStreaming = false;
  }

  async function sendAction(actionKey) {
    const target = actionKey === 'translate' ? await getTranslateTarget() : null;
    const prompt = target !== null ? ACTIONS[actionKey](currentText, target) : ACTIONS[actionKey](currentText);
    streamRequest(prompt);
  }

  function sendFollowUp() {
    const text = inputEl.value.trim();
    if (!text || isStreaming) return;
    inputEl.value = '';
    streamRequest(text);
  }

  function setStreamingUI(streaming) {
    isStreaming = streaming;
    inputEl.disabled = streaming;
    sendBtn.style.display = streaming ? 'none' : 'flex';
    stopBtn.style.display = streaming ? 'flex' : 'none';
  }

  async function streamRequest(userText) {
    setStreamingUI(true);
    conversation.push({ role: 'user', content: userText });
    const userEl = document.createElement('div');
    userEl.className = 'dd-msg dd-msg-user';
    renderUserContent(userEl, userText);
    messagesEl.appendChild(userEl);

    const aiEl = document.createElement('div');
    aiEl.className = 'dd-msg dd-msg-ai';
    aiEl.innerHTML = '<span class="dd-typing"><span></span><span></span><span></span></span>';
    messagesEl.appendChild(aiEl);
    userScrolledUp = false;

    let messages = conversation;
    if (searchEnabled && typeof userText === 'string') {
      aiEl.innerHTML = '<span style="font-size:12px;color:var(--text-secondary);">🌐 正在搜索…</span>';
      try {
        const response = await chrome.runtime.sendMessage({ type: 'web-search', query: userText });
        if (response?.text) {
          messages = [
            { role: 'system', content: `[网络搜索结果，供参考]\n${response.text}\n\n请结合以上搜索信息回答用户问题。` },
            ...conversation,
          ];
        }
      } catch {}
      aiEl.innerHTML = '<span class="dd-typing"><span></span><span></span><span></span></span>';
    } else {
      messages = conversation;
    }

    let aiText = '';
    let rafPending = false;
    activePort = chrome.runtime.connect({ name: 'deepdeep-stream' });
    activePort.postMessage({ type: 'stream', messages });

    activePort.onMessage.addListener((msg) => {
      if (msg.type === 'chunk') {
        aiText += msg.text;
        if (!rafPending) {
          rafPending = true;
          requestAnimationFrame(() => {
            rafPending = false;
            aiEl.innerHTML = sanitize(window.marked.parse(aiText));
            if (!userScrolledUp) messagesEl.scrollTop = messagesEl.scrollHeight;
          });
        }
      } else if (msg.type === 'done') {
        if (rafPending) {
          requestAnimationFrame(() => finishStream(aiEl, aiText));
        } else {
          finishStream(aiEl, aiText);
        }
      } else if (msg.type === 'error') {
        aiEl.innerHTML = `<span class="dd-error">${escapeHtml(msg.message)}</span>`;
        const retryBtn = document.createElement('button');
        retryBtn.className = 'dd-retry-btn';
        retryBtn.textContent = '重试';
        retryBtn.addEventListener('click', () => {
          aiEl.remove();
          conversation.pop();
          streamRequest(userText);
        });
        aiEl.appendChild(retryBtn);
        finishStream(aiEl, aiText, true);
      }
    });

    activePort.onDisconnect.addListener(() => {
      if (isStreaming) finishStream(aiEl, aiText);
    });
  }

  function renderUserContent(el, content) {
    if (typeof content === 'string') {
      el.textContent = content;
      return;
    }
    el.innerHTML = '';
    for (const part of content) {
      if (part.type === 'text' && part.text) {
        const span = document.createElement('span');
        span.textContent = part.text;
        el.appendChild(span);
      } else if (part.type === 'image_url' && part.image_url?.url) {
        const img = document.createElement('img');
        img.className = 'dd-img-thumb';
        img.src = part.image_url.url;
        img.alt = '图片';
        el.appendChild(img);
      }
    }
  }

  async function streamImageRequest() {
    if (!selectedImageUrl) return;
    let dataUrl = '';
    try {
      const res = await chrome.runtime.sendMessage({ type: 'fetch-image', url: selectedImageUrl });
      dataUrl = res?.dataUrl || '';
    } catch {}
    if (!dataUrl) {
      const errEl = document.createElement('div');
      errEl.className = 'dd-msg dd-msg-ai';
      errEl.innerHTML = '<span class="dd-error">图片获取失败（可能过大或无法访问）</span>';
      messagesEl.appendChild(errEl);
      return;
    }
    const content = [
      { type: 'text', text: '请描述这张图片的内容，包括其中的文字、物体、场景等细节。' },
      { type: 'image_url', image_url: { url: dataUrl } },
    ];
    streamRequest(content);
  }

  function stopStream() {
    if (activePort) activePort.postMessage({ type: 'abort' });
  }

  function addActions(el, text) {
    const actions = document.createElement('div');
    actions.className = 'dd-msg-actions';
    const btn = document.createElement('button');
    btn.className = 'dd-msg-action';
    btn.textContent = '复制';
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(text).then(() => { btn.textContent = '已复制'; setTimeout(() => btn.textContent = '复制', 1500); });
    });
    actions.appendChild(btn);
    el.appendChild(actions);
  }

  function finishStream(aiEl, aiText, errored) {
    setStreamingUI(false);
    if (activePort) { activePort = null; }
    if (aiText) {
      conversation.push({ role: 'assistant', content: aiText });
      if (!errored) addActions(aiEl, aiText);
    }
    if (!aiText && !errored) aiEl.innerHTML = '<span class="dd-error">（空回复）</span>';
    inputEl.focus();
  }

  let mouseUpTimer = null;
  document.addEventListener('mouseup', () => {
    clearTimeout(mouseUpTimer);
    mouseUpTimer = setTimeout(() => {
      const text = getSelectionText();
      if (panel && panel.style.display === 'block') return;
      const img = text ? null : getSelectedImage();
      if (img) {
        ensureUI();
        currentText = '';
        selectedImageUrl = img.currentSrc || img.src;
        savedRange = saveSelection();
        showImageToolbar();
      } else if (text && text.length > 0) {
        ensureUI();
        currentText = text;
        selectedImageUrl = null;
        savedRange = saveSelection();
        showToolbar();
      } else {
        hideToolbar();
      }
    }, 150);
  }, true);

  document.addEventListener('mousedown', (e) => {
    if (host && host.contains(e.target)) return;
    if (window.getSelection().toString().trim()) return;
    if (toolbar && toolbar.style.display !== 'none') {
      const tbRect = toolbar.getBoundingClientRect();
      if (e.clientX < tbRect.left || e.clientX > tbRect.right || e.clientY < tbRect.top || e.clientY > tbRect.bottom) {
        hideToolbar();
      }
    }
  }, true);

  window.addEventListener('scroll', () => { if (!panel || panel.style.display !== 'block') hideToolbar(); }, true);
  window.addEventListener('resize', () => {
    hideToolbar();
    if (panel && panel.style.display === 'block') positionPanel();
  });
})();
