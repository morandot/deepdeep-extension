# Deepdeep 隐私政策 / Privacy Policy

**Last updated: 2026-08-03**

Deepdeep ("the Extension") is committed to protecting your privacy. This policy explains what data we collect and how we use it.

## 1. Data We Do NOT Collect

Deepdeep does **not** collect, store, or transmit any personal data to our servers. We do not have servers. The Extension runs entirely in your browser.

- **No analytics** — We do not track your usage.
- **No telemetry** — We do not collect crash reports or performance data.
- **No account** — There is no login or account system.

## 2. Data Stored Locally

The following data is stored in your browser's local storage (`chrome.storage.local`) and never leaves your device unless you explicitly send it to your chosen AI provider:

| Data | Storage | Purpose |
|------|---------|---------|
| API settings (Base URL, API Key, Model, etc.) | `chrome.storage.local` | Connect to your chosen AI provider |
| System prompt, temperature | `chrome.storage.local` | Customize AI behavior |
| Active conversation | `chrome.storage.session` | Persist chat across panel open/close (cleared on browser restart) |

## 3. Data Sent to Third-Party AI Providers

Deepdeep is a **BYOK (Bring Your Own Key)** extension. When you send a message or use a feature (selection popup, side panel chat, page summarization), the following data is sent **directly** from your browser to the AI API provider you configured (e.g., DeepSeek, OpenAI, Claude):

- Your typed messages
- Selected text from web pages (when using the selection popup or context menu)
- Page content (when using page summarization, translate, or explain features — limited to first ~12,000 characters)
- Tab content (when using the `@tab` mention feature — limited to first ~8,000 characters per tab)
- Your system prompt and temperature settings

**This data is governed by your AI provider's privacy policy, not ours.** We have no access to this data.

## 4. Permissions Explained

| Permission | Why It's Needed |
|-----------|-----------------|
| `storage` | Save your API settings (profiles) and conversation history |
| `sidePanel` | Display the chat side panel |
| `contextMenus` | Right-click "explain/translate/summarize" on selected text and "view image" |
| `activeTab` | Access the current tab for page actions |
| `scripting` | Read page content for summarization and `@tab` context |
| `tabs` | List open tabs for the `@tab` mention system |
| `<all_urls>` (host permission) | Content script must work on all pages for text selection popup; fetch images you right-click on (sent directly to your configured AI provider for vision models) |

## 5. API Key Security

Your API key is stored locally in `chrome.storage.local` and is only sent to the API provider you configure (via `Authorization: Bearer` header). It is never logged, shared, or transmitted anywhere else.

## 6. Third-Party Libraries

| Library | License | Purpose |
|---------|---------|---------|
| [marked](https://github.com/markedjs/marked) | MIT | Markdown rendering |
| [DOMPurify](https://github.com/cure53/DOMPurify) | Apache-2.0/MPL-2.0 | HTML sanitization |
| [Lucide](https://github.com/lucide-icons/lucide) | ISC | Icon font |

## 7. Open Source

Deepdeep is open source. You can review all code at: https://github.com/morandot/deepdeep

## 8. Changes to This Policy

We may update this policy as the Extension evolves. Any changes will be posted here.

## 9. Contact

For privacy questions, open an issue at: https://github.com/morandot/deepdeep/issues
