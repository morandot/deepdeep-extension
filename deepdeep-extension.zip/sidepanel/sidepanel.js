import { streamChat, formatError } from '../lib/api.js';
import { getSettings, isConfigured, modelSupportsVision } from '../lib/storage.js';

const $messages = document.getElementById('messages');
const $input = document.getElementById('input');
const $send = document.getElementById('send');
const $clear = document.getElementById('clear');
const $exportMd = document.getElementById('exportMd');
const $settings = document.getElementById('settings');
const $quickActions = document.getElementById('quickActions');
const $modelBadge = document.getElementById('modelBadge');
const $setupBanner = document.getElementById('setupBanner');
const $goSettings = document.getElementById('goSettings');
const $tabDropdown = document.getElementById('tabDropdown');
const $contextChips = document.getElementById('contextChips');
const $searchToggle = document.getElementById('searchToggle');
const $conversations = document.getElementById('conversations');
const $conversationDropdown = document.getElementById('conversationDropdown');

const CONV_KEY = 'deepdeep_conversation';
const CONV_STORE_KEY = 'deepdeep_conversations';
const MAX_CONVERSATIONS = 20;

const PAGE_ACTIONS = {
  summarize: '请总结这个页面的主要内容，用要点列出关键信息：',
  translate: (target) => `请将这个页面的主要内容翻译成${target}：`,
  explain: '请通俗易懂地解释这个页面的主题和核心概念：',
};

const SELECTION_ACTIONS = {
  explain: (t) => `请通俗易懂地解释以下内容：\n\n${t}`,
  translate: (t, target) => `请将以下内容翻译成${target}：\n\n${t}`,
  summarize: (t) => `请用简洁的要点总结以下内容：\n\n${t}`,
};

let conversation = [];
let contextTabs = [];
let isStreaming = false;
let currentAbort = null;
let userScrolledUp = false;
let currentSettings = {};

let tabMentionOpen = false;
let tabMentionItems = [];
let tabMentionIndex = 0;
let tabMentionStartPos = -1;

let clearConfirmTimer = null;
let searchEnabled = false;

$searchToggle.addEventListener('click', () => {
  searchEnabled = !searchEnabled;
  $searchToggle.classList.toggle('active', searchEnabled);
});

function sanitize(html) {
  return window.DOMPurify.sanitize(html, { ALLOWED_TAGS: ['p','br','strong','em','code','pre','ul','ol','li','blockquote','a','table','thead','tbody','tr','th','td','h1','h2','h3','h4','h5','h6','del','sup','sub','hr'], ALLOWED_ATTR: ['href'] });
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

function scrollToBottom(force) {
  if (!force && userScrolledUp) return;
  $messages.scrollTop = $messages.scrollHeight;
}

$messages.addEventListener('scroll', () => {
  const atBottom = $messages.scrollHeight - $messages.scrollTop - $messages.clientHeight < 40;
  userScrolledUp = !atBottom;
});

function setStreamingState(streaming) {
  isStreaming = streaming;
  $send.classList.toggle('streaming', streaming);
  $input.disabled = streaming;
  $quickActions.querySelectorAll('.qa-btn').forEach((b) => b.disabled = streaming);
}

function addBubble(role, htmlContent) {
  const el = document.createElement('div');
  el.className = `msg msg-${role}`;
  el.innerHTML = htmlContent;
  $messages.appendChild(el);
  scrollToBottom();
  return el;
}

function renderMarkdown(text) {
  const raw = window.marked.parse(text);
  const clean = sanitize(raw);
  const wrapper = document.createElement('div');
  wrapper.innerHTML = clean;
  wrapper.querySelectorAll('pre').forEach((pre) => {
    const wrap = document.createElement('div');
    wrap.className = 'code-block-wrapper';
    const btn = document.createElement('button');
    btn.className = 'copy-btn';
    btn.textContent = '复制';
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(pre.textContent).then(() => {
        btn.textContent = '已复制';
        setTimeout(() => (btn.textContent = '复制'), 1500);
      });
    });
    pre.parentNode.insertBefore(wrap, pre);
    wrap.appendChild(pre);
    wrap.appendChild(btn);
  });
  return wrapper.innerHTML;
}

function renderUserContent(content) {
  if (typeof content === 'string') return escapeHtml(content);
  const parts = content.map((p) => {
    if (p.type === 'text' && p.text) return escapeHtml(p.text);
    if (p.type === 'image_url' && p.image_url?.url) return `<img class="msg-img-thumb" src="${p.image_url.url}" alt="图片">`;
    return '';
  });
  return parts.join(' ');
}

function renderMessage(el, m) {
  if (m.role === 'user') {
    el.innerHTML = renderUserContent(m.content);
    el.classList.add('msg-user');
  } else if (m.role === 'assistant') {
    el.innerHTML = renderMarkdown(m.content);
    el.classList.add('msg-ai');
  }
}

function addAiActions(el, text) {
  const actions = document.createElement('div');
  actions.className = 'msg-actions';
  const copyBtn = document.createElement('button');
  copyBtn.className = 'msg-action-btn';
  copyBtn.textContent = '复制';
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = '已复制';
      setTimeout(() => (copyBtn.textContent = '复制'), 1500);
    });
  });
  actions.appendChild(copyBtn);
  el.appendChild(actions);
}

function generateFollowUps(conv) {
  if (conv.length === 0) return [];
  const lastUser = [...conv].reverse().find((m) => m.role === 'user');
  const lastMsg = lastUser?.content || '';
  if (/翻译|translate/i.test(lastMsg)) return ['翻译更多内容', '解释这段翻译', '润色一下'];
  if (/总结|summarize/i.test(lastMsg)) return ['展开说几点', '有什么补充', '用一句话概括'];
  if (/解释|explain/i.test(lastMsg)) return ['举个例子', '更深入地解释', '有什么实际应用'];
  return ['深入解释', '举个例子', '继续'];
}

function addFollowUps(el) {
  const suggestions = generateFollowUps(conversation);
  if (suggestions.length === 0) return;
  const container = document.createElement('div');
  container.className = 'follow-up-suggestions';
  for (const s of suggestions) {
    const chip = document.createElement('button');
    chip.className = 'suggestion-chip';
    chip.textContent = s;
    chip.addEventListener('click', () => { if (!isStreaming) send(s); });
    container.appendChild(chip);
  }
  el.appendChild(container);
}

function renderEmpty() {
  $messages.innerHTML = `
    <div class="empty">
      <div class="empty-icon">
        <i class="icon-message-circle"></i>
      </div>
      <div class="empty-title">Deepdeep</div>
      <div class="empty-hint">划词问答 · 侧边栏对话<br>输入 @ 引用标签页作为上下文</div>
      <div class="empty-chips">
        <div class="chip" data-suggest="summarize"><i class="icon-file-text"></i> 总结当前页面</div>
        <div class="chip" data-suggest="translate"><i class="icon-languages"></i> 翻译当前页面</div>
        <div class="chip" data-suggest="explain"><i class="icon-help-circle"></i> 解释当前页面</div>
      </div>
    </div>`;
  $messages.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => handlePageAction(chip.dataset.suggest));
  });
}

let activeConvId = null;
let convStore = { items: [] };

async function loadConvStore() {
  const data = await chrome.storage.session.get(CONV_STORE_KEY);
  convStore = data[CONV_STORE_KEY] || { items: [] };
  const legacy = await chrome.storage.session.get(CONV_KEY);
  if (legacy[CONV_KEY] && legacy[CONV_KEY].conversation?.length > 0 && convStore.items.length === 0) {
    convStore.items.push({
      id: makeId(),
      title: makeTitle(legacy[CONV_KEY].conversation),
      updatedAt: Date.now(),
      conversation: legacy[CONV_KEY].conversation,
      contextTabs: legacy[CONV_KEY].contextTabs || [],
    });
    await persistConvStore();
    await chrome.storage.session.remove(CONV_KEY).catch(() => {});
  }
  if (convStore.items.length === 0) {
    newConversation(true);
  } else if (!convStore.items.some((i) => i.id === activeConvId)) {
    convStore.items[0].updatedAt = Math.max(convStore.items[0].updatedAt, Date.now());
    await persistConvStore();
    await switchConversation(convStore.items[0].id, true);
  } else {
    await switchConversation(activeConvId, true);
  }
}

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function makeTitle(conv) {
  const first = conv.find((m) => m.role === 'user');
  let t = '';
  if (typeof first?.content === 'string') t = first.content.trim();
  else if (Array.isArray(first?.content)) t = first.content.find((p) => p.type === 'text')?.text?.trim() || '';
  return t ? t.slice(0, 20) : '新对话';
}

async function persistConvStore() {
  await chrome.storage.session.set({ [CONV_STORE_KEY]: convStore });
}

async function saveConversation() {
  if (!activeConvId) return;
  const item = convStore.items.find((i) => i.id === activeConvId);
  if (item) {
    item.conversation = conversation;
    item.contextTabs = contextTabs;
    item.updatedAt = Date.now();
    if (conversation.length === 0) item.title = '新对话';
    else item.title = makeTitle(conversation);
  } else if (conversation.length > 0) {
    convStore.items.unshift({
      id: activeConvId,
      title: makeTitle(conversation),
      updatedAt: Date.now(),
      conversation,
      contextTabs,
    });
  }
  if (convStore.items.length > MAX_CONVERSATIONS) convStore.items.length = MAX_CONVERSATIONS;
  await persistConvStore();
  renderConversationDropdown();
}

function newConversation(silent) {
  activeConvId = makeId();
  conversation = [];
  contextTabs = [];
  $messages.innerHTML = '';
  renderEmpty();
  renderContextChips();
  if (!silent) {
    renderConversationDropdown();
    saveConversation();
  }
}

async function switchConversation(id, silent) {
  const item = convStore.items.find((i) => i.id === id);
  if (!item) return;
  await saveConversation();
  activeConvId = id;
  conversation = item.conversation || [];
  contextTabs = item.contextTabs || [];
  $messages.innerHTML = '';
  const lastAssistantIdx = conversation.findLastIndex ? conversation.findLastIndex((m) => m.role === 'assistant') : -1;
  for (let i = 0; i < conversation.length; i++) {
    const m = conversation[i];
    const el = addBubble('', '');
    renderMessage(el, m);
    if (m.role === 'assistant') {
      addAiActions(el, m.content);
      if (i === lastAssistantIdx) addFollowUps(el);
    }
  }
  if (conversation.length === 0) renderEmpty();
  renderContextChips();
  scrollToBottom(true);
  if (!silent) {
    renderConversationDropdown();
    hideConversationDropdown();
  }
}

async function deleteConversation(id) {
  const idx = convStore.items.findIndex((i) => i.id === id);
  if (idx < 0) return;
  convStore.items.splice(idx, 1);
  await persistConvStore();
  if (id === activeConvId) {
    activeConvId = null;
    if (convStore.items.length > 0) await switchConversation(convStore.items[0].id, true);
    else newConversation(true);
  } else {
    renderConversationDropdown();
  }
}

function renderConversationDropdown() {
  if (!$conversationDropdown) return;
  const sorted = [...convStore.items].sort((a, b) => b.updatedAt - a.updatedAt);
  if (sorted.length === 0) {
    $conversationDropdown.innerHTML = '<div class="conv-empty">暂无历史会话</div>';
    return;
  }
  $conversationDropdown.innerHTML = sorted.map((i) => `
    <div class="conv-item ${i.id === activeConvId ? 'active' : ''}" data-id="${i.id}">
      <span>${escapeHtml(i.title || '新对话')}</span>
      <span class="conv-time">${formatTime(i.updatedAt)}</span>
      <button class="conv-del" data-id="${i.id}" title="删除" aria-label="删除会话">✕</button>
    </div>`).join('') + `
    <div class="conv-new">＋ 新建对话</div>`;
}

function formatTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) {
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

function showConversationDropdown() {
  renderConversationDropdown();
  $conversationDropdown.style.display = 'block';
}

function hideConversationDropdown() {
  $conversationDropdown.style.display = 'none';
}

$conversations.addEventListener('click', (e) => {
  e.stopPropagation();
  if ($conversationDropdown.style.display === 'block') hideConversationDropdown();
  else showConversationDropdown();
});

$conversationDropdown.addEventListener('click', async (e) => {
  const del = e.target.closest('.conv-del');
  if (del) {
    e.stopPropagation();
    deleteConversation(del.dataset.id);
    return;
  }
  const item = e.target.closest('.conv-item');
  if (item) {
    if (item.dataset.id !== activeConvId) switchConversation(item.dataset.id);
    else hideConversationDropdown();
    return;
  }
  if (e.target.closest('.conv-new')) {
    await saveConversation();
    newConversation();
    hideConversationDropdown();
  }
});

document.addEventListener('click', (e) => {
  if (!$conversationDropdown.contains(e.target) && e.target !== $conversations) {
    hideConversationDropdown();
  }
});

async function loadConversation() {
  await loadConvStore();
}

function clearAll() {
  newConversation();
}

async function checkSetup() {
  const configured = await isConfigured();
  $setupBanner.style.display = configured ? 'none' : 'flex';
  currentSettings = await getSettings();
  $modelBadge.textContent = currentSettings.model || '';
  $modelBadge.title = `${currentSettings.model} @ ${currentSettings.baseUrl}`;
}

async function fetchPageContent() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('无法获取当前标签页');
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => document.body.innerText.slice(0, 12000),
  });
  return { tab, title: tab.title || '', url: tab.url || '', text: result?.result || '' };
}

async function handlePageAction(action) {
  if (isStreaming) return;
  if ($messages.querySelector('.empty')) $messages.innerHTML = '';

  addBubble('system', '正在读取页面…');
  let page;
  try {
    page = await fetchPageContent();
  } catch {
    $messages.lastChild.remove();
    addBubble('system', '⚠️ 无法读取当前页面（可能是系统页面）');
    return;
  }
  if (!page.text || page.text.length < 10) {
    $messages.lastChild.remove();
    addBubble('system', '⚠️ 当前页面没有足够的文本内容');
    return;
  }
  $messages.lastChild.remove();

  const existingIdx = contextTabs.findIndex((t) => t.id === page.tab.id);
  const ctxTab = { id: page.tab.id, title: page.title, url: page.url, favIconUrl: page.tab.favIconUrl, text: page.text };
  if (existingIdx >= 0) contextTabs[existingIdx] = ctxTab;
  else contextTabs.push(ctxTab);
  renderContextChips();

  const actionVal = typeof PAGE_ACTIONS[action] === 'function' ? PAGE_ACTIONS[action](currentSettings.translateTarget) : PAGE_ACTIONS[action];
  await send(actionVal);
}

function renderContextChips() {
  $contextChips.innerHTML = '';
  contextTabs.forEach((t, i) => {
    const chip = document.createElement('div');
    chip.className = 'ctx-chip';
    chip.dataset.idx = i;

    if (t.favIconUrl) {
      const img = document.createElement('img');
      img.src = t.favIconUrl;
      img.addEventListener('error', () => img.remove());
      chip.appendChild(img);
    }

    const span = document.createElement('span');
    span.textContent = (t.title || t.url || 'Tab').slice(0, 28);
    chip.appendChild(span);

    const removeBtn = document.createElement('button');
    removeBtn.className = 'ctx-chip-remove';
    removeBtn.dataset.idx = i;
    removeBtn.innerHTML = '<i class="icon-x"></i>';
    chip.appendChild(removeBtn);

    $contextChips.appendChild(chip);
  });
  $contextChips.style.display = contextTabs.length ? 'flex' : 'none';
}

$contextChips.addEventListener('click', (e) => {
  const removeBtn = e.target.closest('.ctx-chip-remove');
  if (removeBtn) {
    const idx = parseInt(removeBtn.dataset.idx);
    contextTabs.splice(idx, 1);
    renderContextChips();
    saveConversation();
  }
});

/* ── @tab Mention System ── */

function checkTabMention() {
  const val = $input.value;
  const pos = $input.selectionStart;
  const before = val.slice(0, pos);
  const match = before.match(/(?:^|\s)@([^\s@\n]*)$/);

  if (match) {
    const atIdx = before.lastIndexOf('@');
    if (atIdx > 0 && !/[\s\n]/.test(val[atIdx - 1])) { closeTabDropdown(); return; }
    tabMentionStartPos = atIdx;
    openTabDropdown(match[1]);
  } else {
    closeTabDropdown();
  }
}

async function openTabDropdown(query) {
  const q = query.toLowerCase();
  let tabs = await chrome.tabs.query({ currentWindow: true });
  tabs = tabs
    .filter((t) => !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://') && !t.url.startsWith('edge://'))
    .filter((t) =>
      !q || (t.title || '').toLowerCase().includes(q) || (t.url || '').toLowerCase().includes(q)
    )
    .slice(0, 8);

  if (tabs.length === 0) { closeTabDropdown(); return; }

  tabMentionItems = tabs;
  tabMentionIndex = 0;
  tabMentionOpen = true;

  const colors = ['#4D6BFE', '#e8590c', '#2ecc71', '#9b59b6', '#e74c3c', '#1abc9c', '#f39c12', '#34495e'];
  $tabDropdown.innerHTML = tabs.map((t, i) => {
    const letter = (t.title || '?').charAt(0).toUpperCase();
    const fallbackBg = colors[i % colors.length];
    return `<div class="tab-item ${i === 0 ? 'selected' : ''}" data-idx="${i}">
      <div class="tab-favicon">
        <div class="tab-favicon-fallback" style="background:${fallbackBg}">${escapeHtml(letter)}</div>
      </div>
      <span class="tab-title">${escapeHtml(t.title || t.url || 'Untitled')}</span>
    </div>`;
  }).join('');

  tabs.forEach((t, i) => {
    if (t.favIconUrl) {
      const faviconContainer = $tabDropdown.querySelectorAll('.tab-favicon')[i];
      const img = document.createElement('img');
      img.src = t.favIconUrl;
      img.addEventListener('error', () => img.remove());
      faviconContainer.appendChild(img);
    }
  });

  $tabDropdown.style.display = 'block';
}

function closeTabDropdown() {
  tabMentionOpen = false;
  $tabDropdown.style.display = 'none';
}

function updateDropdownSelection() {
  $tabDropdown.querySelectorAll('.tab-item').forEach((el, i) => {
    el.classList.toggle('selected', i === tabMentionIndex);
  });
  const sel = $tabDropdown.querySelector('.tab-item.selected');
  if (sel) sel.scrollIntoView({ block: 'nearest' });
}

function selectTabFromDropdown() {
  if (!tabMentionOpen || tabMentionItems.length === 0) return;
  const tab = tabMentionItems[tabMentionIndex];
  const val = $input.value;
  $input.value = val.slice(0, tabMentionStartPos) + val.slice($input.selectionStart);
  $input.selectionStart = $input.selectionEnd = tabMentionStartPos;

  if (!contextTabs.find((t) => t.id === tab.id)) {
    contextTabs.push({ id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl, text: undefined });
    renderContextChips();
  }
  closeTabDropdown();
  $input.focus();
}

$tabDropdown.addEventListener('click', (e) => {
  const item = e.target.closest('.tab-item');
  if (item) {
    tabMentionIndex = parseInt(item.dataset.idx);
    selectTabFromDropdown();
  }
});

/* ── Send / Stream ── */

async function send(text) {
  const isImageMsg = Array.isArray(text);
  if (typeof text === 'string') text = text.trim();
  if (!text || isStreaming) return;
  if ($messages.querySelector('.empty')) $messages.innerHTML = '';
  closeTabDropdown();

  for (const tab of contextTabs) {
    if (tab.text === undefined && tab.id > 0) {
      addBubble('system', `正在读取「${(tab.title || '').slice(0, 20)}」…`);
      try {
        const [result] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => document.body.innerText.slice(0, 8000),
        });
        tab.text = result?.result || '';
      } catch {
        tab.text = '';
      }
      $messages.lastChild.remove();
    }
  }

  conversation.push({ role: 'user', content: text });
  addBubble('user', renderUserContent(text));

  let searchContext = '';
  if (searchEnabled && !isImageMsg) {
    const searchEl = addBubble('system', '🌐 正在搜索…');
    try {
      const response = await chrome.runtime.sendMessage({ type: 'web-search', query: text });
      if (response?.text) {
        searchContext = response.text;
        searchEl.textContent = `🌐 已搜索到相关信息`;
        setTimeout(() => searchEl.remove(), 1500);
      } else {
        searchEl.remove();
      }
    } catch {
      searchEl.remove();
    }
  }

  $input.value = '';
  autoResize();
  userScrolledUp = false;
  setStreamingState(true);

  const aiEl = addBubble('ai', '<span class="typing-dots"><span></span><span></span><span></span></span>');
  let aiText = '';
  let rafPending = false;
  currentAbort = new AbortController();

  try {
    const settings = await getSettings();
    const apiMessages = [];
    if (isImageMsg && !modelSupportsVision(settings)) {
      throw new Error('当前模型不支持图片，请在设置中切换支持视觉的模型（如 gpt-4o、Claude）');
    }
    if (settings.systemPrompt) {
      apiMessages.push({ role: 'system', content: settings.systemPrompt });
    }
    for (const ctx of contextTabs) {
      if (ctx.text) {
        apiMessages.push({ role: 'user', content: `[页面上下文 — ${ctx.title} (${ctx.url})]\n\n${ctx.text.slice(0, 8000)}` });
        apiMessages.push({ role: 'assistant', content: '好的，我已了解该页面内容，请提问。' });
      }
    }
    if (searchContext) {
      apiMessages.push({ role: 'system', content: `[网络搜索结果，供参考]\n${searchContext}\n\n请结合以上搜索信息回答用户问题。` });
    }
    for (const m of conversation) {
      apiMessages.push({ role: m.role, content: m.content });
    }

    for await (const chunk of streamChat(apiMessages, settings, { signal: currentAbort.signal })) {
      aiText += chunk;
      if (!rafPending) {
        rafPending = true;
        requestAnimationFrame(() => {
          rafPending = false;
          aiEl.innerHTML = renderMarkdown(aiText);
          scrollToBottom();
        });
      }
    }

    if (rafPending) await new Promise((r) => requestAnimationFrame(r));

    if (aiText) {
      conversation.push({ role: 'assistant', content: aiText });
      aiEl.innerHTML = renderMarkdown(aiText);
      addAiActions(aiEl, aiText);
      addFollowUps(aiEl);
    } else {
      aiEl.innerHTML = '<span class="error">（空回复）</span>';
    }
  } catch (err) {
    const formatted = formatError(err);
    if (formatted) {
      aiEl.innerHTML = `<span class="error">${escapeHtml(formatted)}</span>`;
      const retryBtn = document.createElement('button');
      retryBtn.className = 'retry-btn';
      retryBtn.textContent = '重试';
      retryBtn.addEventListener('click', () => {
        aiEl.remove();
        conversation.pop();
        send(text);
      });
      aiEl.appendChild(retryBtn);
    } else {
      if (aiText) {
        conversation.push({ role: 'assistant', content: aiText });
        aiEl.innerHTML = renderMarkdown(aiText);
        aiEl.appendChild(Object.assign(document.createElement('span'), { className: 'stopped-tag', textContent: '（已停止）' }));
        addAiActions(aiEl, aiText);
      } else {
        aiEl.innerHTML = '<span style="font-size:12px;color:var(--text-secondary);">已取消</span>';
      }
    }
  } finally {
    currentAbort = null;
    setStreamingState(false);
    $input.focus();
    scrollToBottom();
    saveConversation();
  }
}

function stopStreaming() {
  if (currentAbort) currentAbort.abort();
}

function exportMarkdown() {
  if (conversation.length === 0) return;
  const lines = ['# Deepdeep 对话导出', ''];
  if (contextTabs.length > 0) {
    lines.push('> 页面上下文：');
    for (const t of contextTabs) lines.push(`> - [${t.title}](${t.url})`);
    lines.push('');
  }
  for (const m of conversation) {
    const text = typeof m.content === 'string' ? m.content : (m.content || []).map((p) => p.type === 'text' ? p.text : '').filter(Boolean).join('\n');
    lines.push(`## ${m.role === 'user' ? '🧑 User' : '🤖 Assistant'}`, '', text, '');
  }
  const blob = new Blob([lines.join('\n')], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `deepdeep-${new Date().toISOString().slice(0, 10)}.md`;
  a.click();
  URL.revokeObjectURL(url);
}

function autoResize() {
  $input.style.height = 'auto';
  $input.style.height = Math.min($input.scrollHeight, 120) + 'px';
}

/* ── Pending selection from context menu ── */

async function checkPendingSelection() {
  const { pendingSelection } = await chrome.storage.session.get('pendingSelection');
  if (pendingSelection?.text) {
    await chrome.storage.session.remove('pendingSelection');
    if (isStreaming) return;
    const { text, action } = pendingSelection;
    const promptFn = SELECTION_ACTIONS[action] || SELECTION_ACTIONS.explain;
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addBubble('system', `📎 来自右键菜单的选中文本`);
    setTimeout(() => {
      $messages.lastChild?.remove();
      send(promptFn(text, currentSettings.translateTarget));
    }, 100);
  }
}

async function checkPendingImage() {
  const { pendingImage } = await chrome.storage.session.get('pendingImage');
  if (pendingImage?.url) {
    await chrome.storage.session.remove('pendingImage');
    if (isStreaming) return;
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addBubble('system', '🖼️ 正在读取图片…');
    let dataUrl = '';
    try {
      const res = await chrome.runtime.sendMessage({ type: 'fetch-image', url: pendingImage.url });
      dataUrl = res?.dataUrl || '';
    } catch {}
    $messages.lastChild?.remove();
    if (!dataUrl) {
      addBubble('system', '⚠️ 图片获取失败（可能过大或无法访问）');
      return;
    }
    const content = [
      { type: 'text', text: '请描述这张图片的内容，包括其中的文字、物体、场景等细节。' },
      { type: 'image_url', image_url: { url: dataUrl } },
    ];
    send(content);
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'inject-page' && msg.text) {
    const ctxTab = { id: -1, title: msg.title || msg.url || 'Page', url: msg.url || '', text: msg.text };
    const idx = contextTabs.findIndex((t) => t.url === msg.url);
    if (idx >= 0) contextTabs[idx] = ctxTab;
    else contextTabs.push(ctxTab);
    renderContextChips();
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addBubble('system', `📎 已附加页面：${escapeHtml(msg.title || msg.url)}`);
    saveConversation();
  }
});

/* ── Event Listeners ── */

$input.addEventListener('input', () => {
  autoResize();
  checkTabMention();
});

$input.addEventListener('keydown', (e) => {
  if (tabMentionOpen) {
    if (e.key === 'ArrowDown') { e.preventDefault(); tabMentionIndex = Math.min(tabMentionIndex + 1, tabMentionItems.length - 1); updateDropdownSelection(); return; }
    if (e.key === 'ArrowUp') { e.preventDefault(); tabMentionIndex = Math.max(tabMentionIndex - 1, 0); updateDropdownSelection(); return; }
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); selectTabFromDropdown(); return; }
    if (e.key === 'Escape') { e.preventDefault(); closeTabDropdown(); return; }
  }
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!isStreaming) send($input.value);
  }
});

$send.addEventListener('click', () => {
  if (isStreaming) stopStreaming();
  else send($input.value);
});

$clear.addEventListener('click', () => {
  if (conversation.length === 0 && contextTabs.length === 0) return;
  if (!clearConfirmTimer) {
    $clear.classList.add('confirm');
    $clear.title = '再点一次确认';
    clearConfirmTimer = setTimeout(() => {
      $clear.classList.remove('confirm');
      $clear.title = '新对话';
      clearConfirmTimer = null;
    }, 3000);
  } else {
    clearTimeout(clearConfirmTimer);
    clearConfirmTimer = null;
    $clear.classList.remove('confirm');
    $clear.title = '新对话';
    clearAll();
  }
});

$exportMd.addEventListener('click', exportMarkdown);
$settings.addEventListener('click', () => chrome.runtime.openOptionsPage());
$goSettings.addEventListener('click', () => chrome.runtime.openOptionsPage());
$quickActions.addEventListener('click', (e) => {
  const btn = e.target.closest('.qa-btn');
  if (btn && !btn.disabled) handlePageAction(btn.dataset.action);
});

document.addEventListener('click', (e) => {
  if (tabMentionOpen && !$tabDropdown.contains(e.target) && e.target !== $input) {
    closeTabDropdown();
  }
});

chrome.storage.session.onChanged.addListener((changes) => {
  if (changes.pendingSelection?.newValue) {
    checkPendingSelection();
  }
  if (changes.pendingImage?.newValue) {
    checkPendingImage();
  }
});

/* ── Init ── */

if (window.marked) window.marked.setOptions({ breaks: true, gfm: true });
checkSetup();
await loadConversation();
checkPendingSelection();
checkPendingImage();
$input.focus();
