import { streamChat, formatError } from '../lib/api.js';
import { getSettings, isConfigured, modelSupportsVision } from '../lib/storage.js';

const t = (key, ...args) => chrome.i18n.getMessage(key, args);

document.documentElement.lang = chrome.i18n.getUILanguage();

function localizeHtml() {
  const rx = /__MSG_([A-Za-z0-9_]+)__/g;
  const sub = (m, key) => chrome.i18n.getMessage(key) || m;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    walker.currentNode.data = walker.currentNode.data.replace(rx, sub);
  }
  document.querySelectorAll('[title],[aria-label],[placeholder],[value]').forEach((el) => {
    for (const attr of ['title', 'aria-label', 'placeholder', 'value']) {
      const v = el.getAttribute(attr);
      if (v && v.includes('__MSG_')) el.setAttribute(attr, v.replace(rx, sub));
    }
  });
  if (document.title.includes('__MSG_')) document.title = document.title.replace(rx, sub);
}
localizeHtml();

const $messages = document.getElementById('messages');
const $input = document.getElementById('input');
const $send = document.getElementById('send');
const $clear = document.getElementById('clear');
const $exportMd = document.getElementById('exportMd');
const $settings = document.getElementById('settings');
const $modelBadge = document.getElementById('modelBadge');
const $setupBanner = document.getElementById('setupBanner');
const $goSettings = document.getElementById('goSettings');
const $tabDropdown = document.getElementById('tabDropdown');
const $contextChips = document.getElementById('contextChips');
const $searchToggle = document.getElementById('searchToggle');
const $conversations = document.getElementById('conversations');
const $conversationDropdown = document.getElementById('conversationDropdown');
const $scrollBottom = document.getElementById('scrollBottom');

const CONV_KEY = 'deepdeep_conversation';
const CONV_STORE_KEY = 'deepdeep_conversations';
const MAX_CONVERSATIONS = 20;

const PAGE_ACTIONS = {
  summarize: t('pageActionSummarize'),
  translate: (target) => t('pageActionTranslate', [target]),
  explain: t('pageActionExplain'),
};

const SELECTION_ACTIONS = {
  explain: (text) => t('selActionExplain', [text]),
  translate: (text, target) => t('selActionTranslate', [target, text]),
  summarize: (text) => t('selActionSummarize', [text]),
};

let conversation = [];
let contextTabs = [];
let isStreaming = false;
let currentAbort = null;
let userScrolledUp = false;
let unseenCount = 0;
let currentSettings = {};

let tabMentionOpen = false;
let tabMentionItems = [];
let tabMentionIndex = 0;
let tabMentionStartPos = -1;

let clearConfirmTimer = null;
let searchEnabled = false;
let convSearchQuery = '';

const AI_AVATAR_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" aria-hidden="true"><path fill="currentColor" fill-rule="evenodd" d="M0 64 A64 64 0 0 1 128 64 A64 64 0 0 1 0 64 Z M37 32 L61 32 C79 32 91 46 91 64 C91 82 79 96 61 96 L37 96 Z M51 46 L61 46 C71 46 77 54 77 64 C77 74 71 82 61 82 L51 82 Z"/></svg>';

$searchToggle.addEventListener('click', () => {
  searchEnabled = !searchEnabled;
  $searchToggle.classList.toggle('active', searchEnabled);
});

function sanitize(html) {
  return window.DOMPurify.sanitize(html, { ALLOWED_TAGS: ['p','br','strong','em','code','pre','ul','ol','li','blockquote','a','table','thead','tbody','tr','th','td','h1','h2','h3','h4','h5','h6','del','sup','sub','hr'], ALLOWED_ATTR: ['href','class'] });
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

function scrollToBottom(force) {
  if (!force && userScrolledUp) return;
  $messages.scrollTop = $messages.scrollHeight;
}

$messages.addEventListener('scroll', () => {
  const atBottom = $messages.scrollHeight - $messages.scrollTop - $messages.clientHeight < 40;
  userScrolledUp = !atBottom;
  if (atBottom) hideScrollBottom();
});

function showScrollBottom() {
  $scrollBottom.hidden = false;
  const text = $scrollBottom.querySelector('#scrollBottomText');
  if (unseenCount > 1) {
    text.textContent = t('newMessagesN', [unseenCount]);
    text.hidden = false;
    $scrollBottom.classList.add('counted');
  } else {
    text.hidden = true;
    $scrollBottom.classList.remove('counted');
  }
}
function hideScrollBottom() { unseenCount = 0; $scrollBottom.hidden = true; }
$scrollBottom.addEventListener('click', () => {
  userScrolledUp = false;
  hideScrollBottom();
  scrollToBottom(true);
});
function bumpUnseen() {
  if (userScrolledUp) {
    unseenCount++;
    showScrollBottom();
  }
}

function setStreamingState(streaming) {
  isStreaming = streaming;
  $send.classList.toggle('streaming', streaming);
  $input.disabled = streaming;
}

function addBubble(role, htmlContent) {
  const el = document.createElement('div');
  el.className = `msg msg-${role}`;
  el.innerHTML = htmlContent;
  $messages.appendChild(el);
  bumpUnseen();
  scrollToBottom();
  return el;
}

function addSystemBubble(text) {
  const el = document.createElement('div');
  el.className = 'msg msg-system';
  el.innerHTML = `<span class="spinner"></span>${text}`;
  $messages.appendChild(el);
  bumpUnseen();
  scrollToBottom();
  return el;
}

function addUserBubble(contentHtml) {
  const row = document.createElement('div');
  row.className = 'msg-row';
  const bubble = document.createElement('div');
  bubble.className = 'msg msg-user';
  bubble.innerHTML = contentHtml;
  row.appendChild(bubble);
  $messages.appendChild(row);
  bumpUnseen();
  scrollToBottom();
  return bubble;
}

function addAiBubble(htmlContent) {
  const row = document.createElement('div');
  row.className = 'msg-row';
  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.innerHTML = AI_AVATAR_SVG;
  row.appendChild(avatar);
  const bubble = document.createElement('div');
  bubble.className = 'msg msg-ai';
  bubble.innerHTML = htmlContent;
  row.appendChild(bubble);
  $messages.appendChild(row);
  bumpUnseen();
  scrollToBottom();
  return bubble;
}

function renderMarkdown(text) {
  const raw = window.marked.parse(text);
  const clean = sanitize(raw);
  const wrapper = document.createElement('div');
  wrapper.innerHTML = clean;
  wrapper.querySelectorAll('pre').forEach((pre) => {
    const wrap = document.createElement('div');
    wrap.className = 'code-block-wrapper';
    const langMatch = pre.querySelector('code')?.className.match(/language-([\w+-]+)/);
    if (langMatch) {
      const lang = document.createElement('span');
      lang.className = 'code-lang';
      lang.textContent = langMatch[1];
      wrap.appendChild(lang);
    }
    const btn = document.createElement('button');
    btn.className = 'copy-btn';
    btn.setAttribute('aria-label', t('actionCopy'));
    btn.innerHTML = '<i class="icon-copy"></i>';
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(pre.textContent).then(() => {
        btn.innerHTML = '<i class="icon-check"></i>';
        setTimeout(() => (btn.innerHTML = '<i class="icon-copy"></i>'), 1500);
      });
    });
    pre.parentNode.insertBefore(wrap, pre);
    wrap.appendChild(pre);
    wrap.appendChild(btn);
  });
  return wrapper.innerHTML;
}

function renderUserContent(content) {
  if (typeof content === 'string') return escapeHtml(content);
  const parts = content.map((p) => {
    if (p.type === 'text' && p.text) return escapeHtml(p.text);
    if (p.type === 'image_url' && p.image_url?.url) return `<img class="msg-img-thumb" src="${p.image_url.url}" alt="${t('imageAlt')}">`;
    return '';
  });
  return parts.join(' ');
}

function addEditAction(el, idx) {
  const actions = document.createElement('div');
  actions.className = 'msg-actions';
  const editBtn = document.createElement('button');
  editBtn.className = 'msg-action-btn';
  editBtn.textContent = t('actionEdit');
  editBtn.setAttribute('aria-label', t('editAria'));
  editBtn.addEventListener('click', () => {
    if (isStreaming) return;
    const m = conversation[idx];
    if (!m || typeof m.content !== 'string') return;
    conversation = conversation.slice(0, idx);
    saveConversation();
    renderMessages();
    $input.value = m.content;
    autoResize();
    $input.focus();
  });
  actions.appendChild(editBtn);
  el.appendChild(actions);
}

function renderUserMessage(m, idx) {
  const el = addUserBubble(renderUserContent(m.content));
  if (typeof m.content === 'string') addEditAction(el, idx);
}

function renderAssistantMessage(m, idx, isLastAi) {
  const bubble = addAiBubble(renderMarkdown(m.content));
  addAiActions(bubble, m.content, isLastAi);
  if (isLastAi) addFollowUps(bubble);
}

function addAiActions(el, text, isLastAi) {
  const actions = document.createElement('div');
  actions.className = 'msg-actions';
  const copyBtn = document.createElement('button');
  copyBtn.className = 'msg-action-btn';
  copyBtn.textContent = t('actionCopy');
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = t('actionCopied');
      setTimeout(() => (copyBtn.textContent = t('actionCopy')), 1500);
    });
  });
  actions.appendChild(copyBtn);

  if (isLastAi) {
    const lastUser = [...conversation].reverse().find((m) => m.role === 'user');
    if (lastUser && typeof lastUser.content === 'string') {
      const regenBtn = document.createElement('button');
      regenBtn.className = 'msg-action-btn';
      regenBtn.textContent = t('actionRegenerate');
      regenBtn.setAttribute('aria-label', t('regenerateAria'));
      regenBtn.addEventListener('click', () => {
        if (isStreaming) return;
        const userIdx = conversation.lastIndexOf(lastUser);
        if (userIdx < 0) return;
        conversation = conversation.slice(0, userIdx);
        saveConversation();
        renderMessages();
        send(lastUser.content);
      });
      actions.appendChild(regenBtn);
    }
  }
  el.appendChild(actions);
}

function generateFollowUps(conv) {
  if (conv.length === 0) return [];
  const lastUser = [...conv].reverse().find((m) => m.role === 'user');
  const lastMsg = lastUser?.content || '';
  if (/翻译|translate/i.test(lastMsg)) return [t('fuTranslateMore'), t('fuExplainTranslation'), t('fuPolish')];
  if (/总结|summarize/i.test(lastMsg)) return [t('fuExpand'), t('fuAddMore'), t('fuOneSentence')];
  if (/解释|explain/i.test(lastMsg)) return [t('fuExample'), t('fuDeeper'), t('fuApplications')];
  return [t('fuDeepExplain'), t('fuExample'), t('fuContinue')];
}

function addFollowUps(el) {
  const suggestions = generateFollowUps(conversation);
  if (suggestions.length === 0) return;
  const container = document.createElement('div');
  container.className = 'follow-up-suggestions';
  for (const s of suggestions) {
    const chip = document.createElement('button');
    chip.className = 'suggestion-chip';
    chip.textContent = s;
    chip.addEventListener('click', () => { if (!isStreaming) send(s); });
    container.appendChild(chip);
  }
  el.appendChild(container);
}

function renderEmpty() {
  $messages.innerHTML = `
    <div class="empty">
      <div class="empty-icon">
        <div class="empty-logo">${AI_AVATAR_SVG.replace('<svg', '<svg width="26" height="26"')}</div>
      </div>
      <div class="empty-title">Deepdeep</div>
      <div class="empty-hint">${t('emptyHint')}</div>
      <div class="empty-chips">
        <div class="chip" data-suggest="summarize"><i class="icon-file-text"></i> ${t('chipSummarize')}</div>
        <div class="chip" data-suggest="translate"><i class="icon-languages"></i> ${t('chipTranslate')}</div>
        <div class="chip" data-suggest="explain"><i class="icon-help-circle"></i> ${t('chipExplain')}</div>
      </div>
    </div>`;
  $messages.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => handlePageAction(chip.dataset.suggest));
  });
}

function isSameDay(a, b) {
  return a && b && new Date(a).toDateString() === new Date(b).toDateString();
}

function dateDividerText(ts) {
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return t('today');
  const y = new Date();
  y.setDate(y.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return t('yesterday');
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;
}

function maybeDateDivider(prevTs, ts) {
  if (prevTs && ts && !isSameDay(prevTs, ts)) {
    const div = document.createElement('div');
    div.className = 'date-divider';
    div.textContent = dateDividerText(ts);
    $messages.appendChild(div);
  }
}

function renderMessages() {
  $messages.innerHTML = '';
  let lastAiIdx = -1;
  for (let i = conversation.length - 1; i >= 0; i--) {
    if (conversation[i].role === 'assistant') { lastAiIdx = i; break; }
  }
  for (let i = 0; i < conversation.length; i++) {
    const m = conversation[i];
    maybeDateDivider(conversation[i - 1]?.ts, m.ts);
    if (m.role === 'user') renderUserMessage(m, i);
    else if (m.role === 'assistant') renderAssistantMessage(m, i, i === lastAiIdx);
  }
  if (conversation.length === 0) renderEmpty();
  scrollToBottom(true);
}

let activeConvId = null;
let convStore = { items: [] };

async function loadConvStore() {
  const data = await chrome.storage.local.get(CONV_STORE_KEY);
  convStore = data[CONV_STORE_KEY] || { items: [] };
  const legacy = await chrome.storage.local.get(CONV_KEY);
  if (legacy[CONV_KEY] && legacy[CONV_KEY].conversation?.length > 0 && convStore.items.length === 0) {
    convStore.items.push({
      id: makeId(),
      title: makeTitle(legacy[CONV_KEY].conversation),
      updatedAt: Date.now(),
      conversation: legacy[CONV_KEY].conversation,
      contextTabs: legacy[CONV_KEY].contextTabs || [],
    });
    await persistConvStore();
    await chrome.storage.local.remove(CONV_KEY).catch(() => {});
  }
  if (convStore.items.length === 0) {
    newConversation(true);
  } else if (!convStore.items.some((i) => i.id === activeConvId)) {
    convStore.items[0].updatedAt = Math.max(convStore.items[0].updatedAt, Date.now());
    await persistConvStore();
    await switchConversation(convStore.items[0].id, true);
  } else {
    await switchConversation(activeConvId, true);
  }
}

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function makeTitle(conv) {
  const first = conv.find((m) => m.role === 'user');
  let title = '';
  if (typeof first?.content === 'string') title = first.content.trim();
  else if (Array.isArray(first?.content)) title = first.content.find((p) => p.type === 'text')?.text?.trim() || '';
  return title ? title.slice(0, 20) : t('newConversation');
}

async function persistConvStore() {
  await chrome.storage.local.set({ [CONV_STORE_KEY]: convStore });
}

async function saveConversation() {
  if (!activeConvId) return;
  const item = convStore.items.find((i) => i.id === activeConvId);
  if (item) {
    item.conversation = conversation;
    item.contextTabs = contextTabs;
    item.updatedAt = Date.now();
    if (conversation.length === 0) item.title = t('newConversation');
    else item.title = makeTitle(conversation);
  } else if (conversation.length > 0) {
    convStore.items.unshift({
      id: activeConvId,
      title: makeTitle(conversation),
      updatedAt: Date.now(),
      conversation,
      contextTabs,
    });
  }
  if (convStore.items.length > MAX_CONVERSATIONS) convStore.items.length = MAX_CONVERSATIONS;
  await persistConvStore();
  renderConversationDropdown();
}

function newConversation(silent) {
  activeConvId = makeId();
  conversation = [];
  contextTabs = [];
  $messages.innerHTML = '';
  renderEmpty();
  renderContextChips();
  if (!silent) {
    renderConversationDropdown();
    saveConversation();
  }
}

async function switchConversation(id, silent) {
  const item = convStore.items.find((i) => i.id === id);
  if (!item) return;
  await saveConversation();
  activeConvId = id;
  conversation = item.conversation || [];
  contextTabs = item.contextTabs || [];
  renderMessages();
  renderContextChips();
  if (!silent) {
    renderConversationDropdown();
    hideConversationDropdown();
  }
}

async function deleteConversation(id) {
  const idx = convStore.items.findIndex((i) => i.id === id);
  if (idx < 0) return;
  convStore.items.splice(idx, 1);
  await persistConvStore();
  if (id === activeConvId) {
    activeConvId = null;
    if (convStore.items.length > 0) await switchConversation(convStore.items[0].id, true);
    else newConversation(true);
  } else {
    renderConversationDropdown();
  }
}

function renderConversationDropdown() {
  if (!$conversationDropdown) return;
  $conversationDropdown.innerHTML = `
    <div class="conv-search"><input type="text" id="convSearchInput" placeholder="${t('convSearchPlaceholder')}" aria-label="${t('convSearchPlaceholder')}"></div>
    <div class="conv-list"></div>
    <div class="conv-new">${t('convNew')}</div>`;
  renderConvList();
}

function renderConvList() {
  const list = $conversationDropdown.querySelector('.conv-list');
  if (!list) return;
  const q = convSearchQuery.trim().toLowerCase();
  const sorted = [...convStore.items]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .filter((i) => !q || (i.title || '').toLowerCase().includes(q));
  if (sorted.length === 0) {
    list.innerHTML = `<div class="conv-empty">${convSearchQuery ? t('convEmptySearch') : t('convEmpty')}</div>`;
    return;
  }
  list.innerHTML = sorted.map((i) => `
    <div class="conv-item ${i.id === activeConvId ? 'active' : ''}" data-id="${i.id}">
      <span>${escapeHtml(i.title || t('newConversation'))}</span>
      <span class="conv-time">${formatTime(i.updatedAt)}</span>
      <button class="conv-del" data-id="${i.id}" title="${t('actionDelete')}" aria-label="${t('deleteConvAria')}">✕</button>
    </div>`).join('');
}

function formatTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) {
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

function showConversationDropdown() {
  renderConversationDropdown();
  $conversationDropdown.style.display = 'block';
}

function hideConversationDropdown() {
  $conversationDropdown.style.display = 'none';
}

$conversations.addEventListener('click', (e) => {
  e.stopPropagation();
  if ($conversationDropdown.style.display === 'block') hideConversationDropdown();
  else showConversationDropdown();
});

$conversationDropdown.addEventListener('click', async (e) => {
  const del = e.target.closest('.conv-del');
  if (del) {
    e.stopPropagation();
    deleteConversation(del.dataset.id);
    return;
  }
  const item = e.target.closest('.conv-item');
  if (item) {
    if (item.dataset.id !== activeConvId) switchConversation(item.dataset.id);
    else hideConversationDropdown();
    return;
  }
  if (e.target.closest('.conv-new')) {
    await saveConversation();
    newConversation();
    hideConversationDropdown();
  }
});

$conversationDropdown.addEventListener('input', (e) => {
  if (e.target.id !== 'convSearchInput') return;
  e.stopPropagation();
  convSearchQuery = e.target.value;
  renderConvList();
});

document.addEventListener('click', (e) => {
  if (!$conversationDropdown.contains(e.target) && e.target !== $conversations) {
    hideConversationDropdown();
  }
});

async function loadConversation() {
  await loadConvStore();
}

function clearAll() {
  newConversation();
}

async function checkSetup() {
  const configured = await isConfigured();
  $setupBanner.style.display = configured ? 'none' : 'flex';
  currentSettings = await getSettings();
  if (!configured) {
    $modelBadge.textContent = t('modelNotConfigured');
    $modelBadge.classList.add('unconfigured');
    $modelBadge.title = t('setupBanner');
  } else {
    $modelBadge.textContent = currentSettings.model || '';
    $modelBadge.classList.remove('unconfigured');
    $modelBadge.title = `${currentSettings.model} @ ${currentSettings.baseUrl}`;
  }
}

async function fetchPageContent() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error(t('errNoCurrentTab'));
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => document.body.innerText.slice(0, 12000),
  });
  return { tab, title: tab.title || '', url: tab.url || '', text: result?.result || '' };
}

async function handlePageAction(action) {
  if (isStreaming) return;
  if ($messages.querySelector('.empty')) $messages.innerHTML = '';

  addSystemBubble(t('readingPage'));
  let page;
  try {
    page = await fetchPageContent();
  } catch {
    $messages.lastChild.remove();
    addBubble('system', t('errCannotReadPage'));
    return;
  }
  if (!page.text || page.text.length < 10) {
    $messages.lastChild.remove();
    addBubble('system', t('errNotEnoughText'));
    return;
  }
  $messages.lastChild.remove();

  const existingIdx = contextTabs.findIndex((tab) => tab.id === page.tab.id);
  const ctxTab = { id: page.tab.id, title: page.title, url: page.url, favIconUrl: page.tab.favIconUrl, text: page.text };
  if (existingIdx >= 0) contextTabs[existingIdx] = ctxTab;
  else contextTabs.push(ctxTab);
  renderContextChips();

  const actionVal = typeof PAGE_ACTIONS[action] === 'function' ? PAGE_ACTIONS[action](currentSettings.translateTarget) : PAGE_ACTIONS[action];
  await send(actionVal);
}

function renderContextChips() {
  $contextChips.innerHTML = '';
  contextTabs.forEach((tab, i) => {
    const chip = document.createElement('div');
    chip.className = 'ctx-chip';
    chip.dataset.idx = i;

    if (tab.favIconUrl) {
      const img = document.createElement('img');
      img.src = tab.favIconUrl;
      img.addEventListener('error', () => img.remove());
      chip.appendChild(img);
    }

    const span = document.createElement('span');
    span.textContent = (tab.title || tab.url || 'Tab').slice(0, 28);
    chip.appendChild(span);

    const removeBtn = document.createElement('button');
    removeBtn.className = 'ctx-chip-remove';
    removeBtn.dataset.idx = i;
    removeBtn.innerHTML = '<i class="icon-x"></i>';
    chip.appendChild(removeBtn);

    $contextChips.appendChild(chip);
  });
  $contextChips.style.display = contextTabs.length ? 'flex' : 'none';
}

$contextChips.addEventListener('click', (e) => {
  const removeBtn = e.target.closest('.ctx-chip-remove');
  if (removeBtn) {
    const idx = parseInt(removeBtn.dataset.idx);
    contextTabs.splice(idx, 1);
    renderContextChips();
    saveConversation();
  }
});

/* ── @tab Mention System ── */

function checkTabMention() {
  const val = $input.value;
  const pos = $input.selectionStart;
  const before = val.slice(0, pos);
  const match = before.match(/(?:^|\s)@([^\s@\n]*)$/);

  if (match) {
    const atIdx = before.lastIndexOf('@');
    if (atIdx > 0 && !/[\s\n]/.test(val[atIdx - 1])) { closeTabDropdown(); return; }
    tabMentionStartPos = atIdx;
    openTabDropdown(match[1]);
  } else {
    closeTabDropdown();
  }
}

async function openTabDropdown(query) {
  const q = query.toLowerCase();
  let tabs = await chrome.tabs.query({ currentWindow: true });
  tabs = tabs
    .filter((tab) => !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://') && !tab.url.startsWith('edge://'))
    .filter((tab) =>
      !q || (tab.title || '').toLowerCase().includes(q) || (tab.url || '').toLowerCase().includes(q)
    )
    .slice(0, 8);

  if (tabs.length === 0) { closeTabDropdown(); return; }

  tabMentionItems = tabs;
  tabMentionIndex = 0;
  tabMentionOpen = true;

  const colors = ['#4D6BFE', '#e8590c', '#2ecc71', '#9b59b6', '#e74c3c', '#1abc9c', '#f39c12', '#34495e'];
  $tabDropdown.innerHTML = tabs.map((tab, i) => {
    const letter = (tab.title || '?').charAt(0).toUpperCase();
    const fallbackBg = colors[i % colors.length];
    return `<div class="tab-item ${i === 0 ? 'selected' : ''}" data-idx="${i}">
      <div class="tab-favicon">
        <div class="tab-favicon-fallback" style="background:${fallbackBg}">${escapeHtml(letter)}</div>
      </div>
      <span class="tab-title">${escapeHtml(tab.title || tab.url || 'Untitled')}</span>
    </div>`;
  }).join('');

  tabs.forEach((tab, i) => {
    if (tab.favIconUrl) {
      const faviconContainer = $tabDropdown.querySelectorAll('.tab-favicon')[i];
      const img = document.createElement('img');
      img.src = tab.favIconUrl;
      img.addEventListener('error', () => img.remove());
      faviconContainer.appendChild(img);
    }
  });

  $tabDropdown.style.display = 'block';
}

function closeTabDropdown() {
  tabMentionOpen = false;
  $tabDropdown.style.display = 'none';
}

function updateDropdownSelection() {
  $tabDropdown.querySelectorAll('.tab-item').forEach((el, i) => {
    el.classList.toggle('selected', i === tabMentionIndex);
  });
  const sel = $tabDropdown.querySelector('.tab-item.selected');
  if (sel) sel.scrollIntoView({ block: 'nearest' });
}

function selectTabFromDropdown() {
  if (!tabMentionOpen || tabMentionItems.length === 0) return;
  const tab = tabMentionItems[tabMentionIndex];
  const val = $input.value;
  $input.value = val.slice(0, tabMentionStartPos) + val.slice($input.selectionStart);
  $input.selectionStart = $input.selectionEnd = tabMentionStartPos;

  if (!contextTabs.find((ctx) => ctx.id === tab.id)) {
    contextTabs.push({ id: tab.id, title: tab.title, url: tab.url, favIconUrl: tab.favIconUrl, text: undefined });
    renderContextChips();
  }
  closeTabDropdown();
  $input.focus();
}

$tabDropdown.addEventListener('click', (e) => {
  const item = e.target.closest('.tab-item');
  if (item) {
    tabMentionIndex = parseInt(item.dataset.idx);
    selectTabFromDropdown();
  }
});

/* ── Send / Stream ── */

async function send(text) {
  const isImageMsg = Array.isArray(text);
  if (typeof text === 'string') text = text.trim();
  if (!text || isStreaming) return;
  if ($messages.querySelector('.empty')) $messages.innerHTML = '';
  closeTabDropdown();

  for (const tab of contextTabs) {
    if (tab.text === undefined && tab.id > 0) {
      addSystemBubble(t('readingTab', [(tab.title || '').slice(0, 20)]));
      try {
        const [result] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => document.body.innerText.slice(0, 8000),
        });
        tab.text = result?.result || '';
      } catch {
        tab.text = '';
      }
      $messages.lastChild.remove();
    }
  }

  conversation.push({ role: 'user', content: text, ts: Date.now() });
  const userEl = addBubble('user', renderUserContent(text));
  if (typeof text === 'string') addEditAction(userEl, conversation.length - 1);

  let searchContext = '';
  if (searchEnabled && !isImageMsg) {
    const searchEl = addSystemBubble(t('searching'));
    try {
      const response = await chrome.runtime.sendMessage({ type: 'web-search', query: text });
      if (response?.text) {
        searchContext = response.text;
        searchEl.textContent = t('searchDone');
        setTimeout(() => searchEl.remove(), 1500);
      } else {
        searchEl.remove();
      }
    } catch {
      searchEl.remove();
    }
  }

  $input.value = '';
  autoResize();
  userScrolledUp = false;
  setStreamingState(true);

  const aiEl = addAiBubble('<span class="stream-caret"></span>');
  let aiText = '';
  let rafPending = false;
  currentAbort = new AbortController();

  try {
    const settings = await getSettings();
    const apiMessages = [];
    if (isImageMsg && !modelSupportsVision(settings)) {
      throw new Error(t('errNoVision'));
    }
    if (settings.systemPrompt) {
      apiMessages.push({ role: 'system', content: settings.systemPrompt });
    }
    for (const ctx of contextTabs) {
      if (ctx.text) {
        apiMessages.push({ role: 'user', content: t('pageContextPrompt', [ctx.title, ctx.url, ctx.text.slice(0, 8000)]) });
        apiMessages.push({ role: 'assistant', content: t('pageContextAck') });
      }
    }
    if (searchContext) {
      apiMessages.push({ role: 'system', content: t('searchSystemPrompt', [searchContext]) });
    }
    for (const m of conversation) {
      apiMessages.push({ role: m.role, content: m.content });
    }

    for await (const chunk of streamChat(apiMessages, settings, { signal: currentAbort.signal })) {
      aiText += chunk;
      if (!rafPending) {
        rafPending = true;
        requestAnimationFrame(() => {
          rafPending = false;
          aiEl.innerHTML = renderMarkdown(aiText) + '<span class="stream-caret"></span>';
          scrollToBottom();
        });
      }
    }

    if (rafPending) await new Promise((r) => requestAnimationFrame(r));

    if (aiText) {
      conversation.push({ role: 'assistant', content: aiText, ts: Date.now() });
      aiEl.innerHTML = renderMarkdown(aiText);
      addAiActions(aiEl, aiText, true);
      addFollowUps(aiEl);
    } else {
      aiEl.innerHTML = `<span class="error">${t('emptyReply')}</span>`;
    }
  } catch (err) {
    const formatted = formatError(err);
    if (formatted) {
      aiEl.innerHTML = `<span class="error">${escapeHtml(formatted)}</span>`;
      const retryBtn = document.createElement('button');
      retryBtn.className = 'retry-btn';
      retryBtn.textContent = t('actionRetry');
      retryBtn.addEventListener('click', () => {
        const userEls = $messages.querySelectorAll('.msg-user');
        userEls[userEls.length - 1]?.remove();
        aiEl.remove();
        conversation.pop();
        send(text);
      });
      aiEl.appendChild(retryBtn);
    } else {
      if (aiText) {
        conversation.push({ role: 'assistant', content: aiText, ts: Date.now() });
        aiEl.innerHTML = renderMarkdown(aiText);
        aiEl.appendChild(Object.assign(document.createElement('span'), { className: 'stopped-tag', textContent: t('stoppedTag') }));
        addAiActions(aiEl, aiText, true);
      } else {
        aiEl.innerHTML = `<span style="font-size:12px;color:var(--text-secondary);">${t('cancelled')}</span>`;
      }
    }
  } finally {
    currentAbort = null;
    setStreamingState(false);
    $input.focus();
    scrollToBottom();
    saveConversation();
  }
}

function stopStreaming() {
  if (currentAbort) currentAbort.abort();
}

function exportMarkdown() {
  if (conversation.length === 0) return;
  const lines = [t('exportTitle'), ''];
  if (contextTabs.length > 0) {
    lines.push(`> ${t('exportContext')}`);
    for (const t of contextTabs) lines.push(`> - [${t.title}](${t.url})`);
    lines.push('');
  }
  for (const m of conversation) {
    const text = typeof m.content === 'string' ? m.content : (m.content || []).map((p) => p.type === 'text' ? p.text : '').filter(Boolean).join('\n');
    lines.push(`## ${m.role === 'user' ? '🧑 User' : '🤖 Assistant'}`, '', text, '');
  }
  const blob = new Blob([lines.join('\n')], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `deepdeep-${new Date().toISOString().slice(0, 10)}.md`;
  a.click();
  URL.revokeObjectURL(url);
}

function autoResize() {
  $input.style.height = 'auto';
  $input.style.height = Math.min($input.scrollHeight, 120) + 'px';
}

/* ── Pending selection from context menu ── */

async function checkPendingSelection() {
  const { pendingSelection } = await chrome.storage.session.get('pendingSelection');
  if (pendingSelection?.text) {
    await chrome.storage.session.remove('pendingSelection');
    if (isStreaming) return;
    const { text, action } = pendingSelection;
    const promptFn = SELECTION_ACTIONS[action] || SELECTION_ACTIONS.explain;
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addSystemBubble(t('fromContextMenu'));
    setTimeout(() => {
      $messages.lastChild?.remove();
      send(promptFn(text, currentSettings.translateTarget));
    }, 100);
  }
}

async function checkPendingImage() {
  const { pendingImage } = await chrome.storage.session.get('pendingImage');
  if (pendingImage?.url) {
    await chrome.storage.session.remove('pendingImage');
    if (isStreaming) return;
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addSystemBubble(t('readingImage'));
    let dataUrl = '';
    try {
      const res = await chrome.runtime.sendMessage({ type: 'fetch-image', url: pendingImage.url });
      dataUrl = res?.dataUrl || '';
    } catch {}
    $messages.lastChild?.remove();
    if (!dataUrl) {
      addBubble('system', t('errImageFetch'));
      return;
    }
    const content = [
      { type: 'text', text: t('describeImagePrompt') },
      { type: 'image_url', image_url: { url: dataUrl } },
    ];
    send(content);
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'inject-page' && msg.text) {
    const ctxTab = { id: -1, title: msg.title || msg.url || 'Page', url: msg.url || '', text: msg.text };
    const idx = contextTabs.findIndex((t) => t.url === msg.url);
    if (idx >= 0) contextTabs[idx] = ctxTab;
    else contextTabs.push(ctxTab);
    renderContextChips();
    if ($messages.querySelector('.empty')) $messages.innerHTML = '';
    addBubble('system', t('pageAttached', [msg.title || msg.url]));
    saveConversation();
  }
});

/* ── Event Listeners ── */

$input.addEventListener('input', () => {
  autoResize();
  checkTabMention();
});

$input.addEventListener('keydown', (e) => {
  if (tabMentionOpen) {
    if (e.key === 'ArrowDown') { e.preventDefault(); tabMentionIndex = Math.min(tabMentionIndex + 1, tabMentionItems.length - 1); updateDropdownSelection(); return; }
    if (e.key === 'ArrowUp') { e.preventDefault(); tabMentionIndex = Math.max(tabMentionIndex - 1, 0); updateDropdownSelection(); return; }
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); selectTabFromDropdown(); return; }
    if (e.key === 'Escape') { e.preventDefault(); closeTabDropdown(); return; }
  }
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!isStreaming) send($input.value);
  }
});

$send.addEventListener('click', () => {
  if (isStreaming) stopStreaming();
  else send($input.value);
});

$clear.addEventListener('click', () => {
  if (conversation.length === 0 && contextTabs.length === 0) return;
  if (!clearConfirmTimer) {
    $clear.classList.add('confirm');
    $clear.title = t('clearConfirm');
    clearConfirmTimer = setTimeout(() => {
      $clear.classList.remove('confirm');
      $clear.title = t('newConversation');
      clearConfirmTimer = null;
    }, 3000);
  } else {
    clearTimeout(clearConfirmTimer);
    clearConfirmTimer = null;
    $clear.classList.remove('confirm');
    $clear.title = t('newConversation');
    clearAll();
  }
});

$exportMd.addEventListener('click', exportMarkdown);
$settings.addEventListener('click', () => chrome.runtime.openOptionsPage());
$goSettings.addEventListener('click', () => chrome.runtime.openOptionsPage());
$modelBadge.addEventListener('click', () => chrome.runtime.openOptionsPage());

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    hideConversationDropdown();
    closeTabDropdown();
  }
});

document.addEventListener('click', (e) => {
  if (tabMentionOpen && !$tabDropdown.contains(e.target) && e.target !== $input) {
    closeTabDropdown();
  }
});

chrome.storage.session.onChanged.addListener((changes) => {
  if (changes.pendingSelection?.newValue) {
    checkPendingSelection();
  }
  if (changes.pendingImage?.newValue) {
    checkPendingImage();
  }
});
/* ── Init ── */

if (window.marked) window.marked.setOptions({ breaks: true, gfm: true });
checkSetup();
await loadConversation();
checkPendingSelection();
checkPendingImage();
$input.focus();
