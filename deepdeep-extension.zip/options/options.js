import { getSettings, saveSettings, PROVIDER_PRESETS, findPreset, listProfiles, getActiveProfile, switchProfile, createProfile, renameProfile, deleteProfile, isConfigured } from '../lib/storage.js';
import { testConnection, fetchModels, formatError } from '../lib/api.js';

const t = (key, ...args) => chrome.i18n.getMessage(key, args);

document.documentElement.lang = chrome.i18n.getUILanguage();

function localizeHtml() {
  const rx = /__MSG_([A-Za-z0-9_]+)__/g;
  const sub = (m, key) => chrome.i18n.getMessage(key) || m;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    walker.currentNode.data = walker.currentNode.data.replace(rx, sub);
  }
  document.querySelectorAll('[title],[aria-label],[placeholder],[value]').forEach((el) => {
    for (const attr of ['title', 'aria-label', 'placeholder', 'value']) {
      const v = el.getAttribute(attr);
      if (v && v.includes('__MSG_')) el.setAttribute(attr, v.replace(rx, sub));
    }
  });
  if (document.title.includes('__MSG_')) document.title = document.title.replace(rx, sub);
}
localizeHtml();

const $ = (id) => document.getElementById(id);

let currentSettings = {};
let saveTimer = null;

async function init() {
  await refreshProfileSelect();
  currentSettings = await getSettings();
  renderPresets();
  fillForm(currentSettings);
  bindEvents();
  const done = await getOnboardingDone();
  if (!done) {
    startOnboarding();
  } else {
    hideOnboarding();
  }
}

const OB_DONE_KEY = 'deepdeep_onboarding_done';
async function getOnboardingDone() {
  const data = await chrome.storage.local.get(OB_DONE_KEY);
  return !!data[OB_DONE_KEY];
}
async function setOnboardingDone(v) {
  await chrome.storage.local.set({ [OB_DONE_KEY]: v });
}

const $obModal = () => document.getElementById('onboardingModal');
const $obBody = () => document.getElementById('obBody');
const $obProgress = () => document.getElementById('obProgress');
const $obStepLabel = () => document.getElementById('obStepLabel');
const $obBack = () => document.getElementById('obBack');
const $obNext = () => document.getElementById('obNext');
const $obSkip = () => document.getElementById('obSkip');

let obStep = 1;
let obState = { presetId: null, baseUrl: '', apiKey: '', model: '', testOk: false };

function hideOnboarding() {
  $obModal().hidden = true;
  document.body.style.overflow = '';
}

function startOnboarding() {
  obStep = 1;
  obState = { presetId: null, baseUrl: '', apiKey: '', model: '', testOk: false };
  $obModal().hidden = false;
  document.body.style.overflow = 'hidden';
  bindObEvents();
  renderObStep();
}

function bindObEvents() {
  if ($obNext()._bound) return;
  $obNext()._bound = true;
  $obNext().addEventListener('click', obNext);
  $obBack().addEventListener('click', obBack);
  $obSkip().addEventListener('click', obSkip);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$obModal().hidden) obSkip();
  });
}

function obSkip() {
  setOnboardingDone(true);
  hideOnboarding();
}

function obBack() {
  if (obStep > 1) {
    obStep--;
    renderObStep();
  }
}

function obNext() {
  if (obStep === 1 && !obState.presetId) return;
  if (obStep === 2 && !obState.testOk) return;
  if (obStep === 4) {
    commitOnboarding();
    setOnboardingDone(true);
    hideOnboarding();
    return;
  }
  obStep++;
  renderObStep();
}

function renderObStep() {
  $obProgress().value = obStep * 25;
  $obStepLabel().textContent = t('onboardingProgressLabel', [obStep]);
  $obBack().disabled = obStep === 1;
  $obNext().disabled = (obStep === 1 && !obState.presetId) || (obStep === 2 && !obState.testOk);
  if (obStep === 4) $obNext().textContent = t('onboardingFinish');
  else $obNext().textContent = t('onboardingNext');
  if (obStep === 1) renderObStep1();
  else if (obStep === 2) renderObStep2();
  else if (obStep === 3) renderObStep3();
  else if (obStep === 4) renderObStep4();
}

function renderObStep1() {
  const body = $obBody();
  body.innerHTML = `
    <div class="ob-title">${t('onboardingStep1Title')}</div>
    <div class="ob-desc">${t('onboardingStep1Desc')}</div>
    <div class="ob-grid" id="obGrid"></div>
  `;
  const grid = body.querySelector('#obGrid');
  for (const preset of PROVIDER_PRESETS) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'ob-preset';
    if (obState.presetId === preset.id) card.classList.add('active');
    const nameRow = document.createElement('span');
    nameRow.className = 'pc-name-row';
    if (preset.color) {
      const dot = document.createElement('span');
      dot.className = 'pc-dot';
      dot.style.background = preset.color;
      dot.style.boxShadow = `0 0 0 2px ${preset.color}22`;
      nameRow.appendChild(dot);
    }
    const name = document.createElement('span');
    name.className = 'pc-name';
    name.textContent = preset.name;
    nameRow.appendChild(name);
    const desc = document.createElement('span');
    desc.className = 'pc-desc';
    desc.textContent = preset.id === 'custom' ? t('customPresetDesc') : (preset.id === 'openrouter' ? t('openrouterDesc') : (preset.models[0] || ''));
    card.append(nameRow, desc);
    card.addEventListener('click', () => {
      obState.presetId = preset.id;
      obState.baseUrl = preset.baseUrl;
      obState.model = preset.model;
      obState.testOk = false;
      grid.querySelectorAll('.ob-preset').forEach((c) => c.classList.remove('active'));
      card.classList.add('active');
      $obNext().disabled = false;
    });
    grid.appendChild(card);
  }
}

function renderObStep2() {
  const body = $obBody();
  body.innerHTML = `
    <div class="ob-title">${t('onboardingStep2Title')}</div>
    <div class="ob-desc">${t('onboardingStep2Desc')}</div>
    <div class="ob-field">
      <label>Base URL</label>
      <input type="text" id="obBaseUrl" value="${escapeHtmlAttr(obState.baseUrl)}" autocomplete="off">
    </div>
    <div class="ob-field">
      <label>API Key</label>
      <input type="password" id="obApiKey" value="${escapeHtmlAttr(obState.apiKey)}" autocomplete="off">
    </div>
    <div class="ob-test-row">
      <button type="button" id="obTestBtn" class="ob-test-btn">${t('testConnection')}</button>
      <span class="ob-test-status" id="obTestStatus"></span>
    </div>
  `;
  body.querySelector('#obBaseUrl').addEventListener('input', (e) => { obState.baseUrl = e.target.value.trim(); obState.testOk = false; updateObTestStatus(); $obNext().disabled = true; });
  body.querySelector('#obApiKey').addEventListener('input', (e) => { obState.apiKey = e.target.value.trim(); obState.testOk = false; updateObTestStatus(); $obNext().disabled = true; });
  body.querySelector('#obTestBtn').addEventListener('click', obRunTest);
  updateObTestStatus();
}

function updateObTestStatus() {
  const el = document.getElementById('obTestStatus');
  if (!el) return;
  el.className = 'ob-test-status';
  if (obState.testOk) { el.className = 'ob-test-status ok'; el.textContent = `✓ ${t('connSuccess', ['?'])}`; }
  else if (obState.baseUrl || obState.apiKey) { el.className = 'ob-test-status'; el.textContent = t('onboardingTestRequired'); }
  else el.textContent = '';
}

async function obRunTest() {
  const btn = document.getElementById('obTestBtn');
  const status = document.getElementById('obTestStatus');
  btn.disabled = true;
  btn.setAttribute('aria-busy', 'true');
  btn.innerHTML = `<span class="spinner"></span>${t('testing')}`;
  status.className = 'ob-test-status';
  status.textContent = t('connecting');
  try {
    const data = await testConnection(obState);
    const count = data.data?.length ?? '?';
    obState.testOk = true;
    status.className = 'ob-test-status ok';
    status.textContent = `✓ ${t('connSuccess', [count])}`;
    $obNext().disabled = false;
  } catch (err) {
    obState.testOk = false;
    status.className = 'ob-test-status err';
    status.textContent = `✕ ${formatError(err)}`;
    $obNext().disabled = true;
  } finally {
    btn.disabled = false;
    btn.removeAttribute('aria-busy');
    btn.textContent = t('testConnection');
  }
}

function renderObStep3() {
  const body = $obBody();
  body.innerHTML = `
    <div class="ob-title">${t('onboardingStep3Title')}</div>
    <div class="ob-desc">${t('onboardingStep3Desc')}</div>
    <div class="ob-field">
      <label>${t('fetchModels')}</label>
      <div class="ob-test-row">
        <input type="text" id="obModel" value="${escapeHtmlAttr(obState.model)}" autocomplete="off" placeholder="__MSG_customModelPlaceholder__" style="flex:1">
        <button type="button" id="obFetchBtn" class="ob-fetch">${t('fetchModels')}</button>
      </div>
      <select id="obModelSelect" class="ob-select" style="margin-top:8px"></select>
    </div>
  `;
  body.querySelector('#obModel').addEventListener('input', (e) => { obState.model = e.target.value.trim(); });
  const select = body.querySelector('#obModelSelect');
  const preset = findPreset(obState.baseUrl);
  const merged = [...new Set([...(preset.models || []), ...(obState.models || [])])];
  if (merged.length > 0) {
    for (const m of merged) {
      const opt = document.createElement('option');
      opt.value = m; opt.textContent = m;
      if (m === obState.model) opt.selected = true;
      select.appendChild(opt);
    }
    select.addEventListener('change', (e) => {
      obState.model = e.target.value;
      body.querySelector('#obModel').value = e.target.value;
    });
  } else {
    select.style.display = 'none';
  }
  body.querySelector('#obFetchBtn').addEventListener('click', obFetchModels);
}

async function obFetchModels() {
  const btn = document.getElementById('obFetchBtn');
  btn.disabled = true;
  const original = btn.textContent;
  btn.textContent = t('fetchingModels');
  try {
    const models = await fetchModels(obState);
    if (models.length === 0) { return; }
    obState.models = models;
    const select = document.getElementById('obModelSelect');
    select.style.display = '';
    select.innerHTML = '';
    for (const m of models) {
      const opt = document.createElement('option');
      opt.value = m; opt.textContent = m;
      if (m === obState.model) opt.selected = true;
      select.appendChild(opt);
    }
    if (!models.includes(obState.model) && models[0]) {
      obState.model = models[0];
      document.getElementById('obModel').value = models[0];
      select.value = models[0];
    }
  } catch (err) {
    // ignore fetch errors, user can manually enter
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
}

function renderObStep4() {
  const body = $obBody();
  const isMac = navigator.platform.toLowerCase().includes('mac');
  const kbd = isMac ? '⌘+Shift+D' : 'Ctrl+Shift+D';
  body.innerHTML = `
    <div class="ob-title">${t('onboardingCompleteTitle')}</div>
    <div class="ob-done-icon">✓</div>
    <div class="ob-desc" style="text-align:center;font-weight:600;color:var(--success);font-size:14px">${t('onboardingCompleteShort')}</div>
    <div class="ob-desc">${t('onboardingStep4Desc')}</div>
    <div style="text-align:center;font-size:13px;color:var(--text-secondary)">
      <span class="ob-keyboard">${kbd}</span>
    </div>
  `;
}

async function commitOnboarding() {
  obState.model = obState.model || findPreset(obState.baseUrl).model || '';
  const cur = await getSettings();
  await saveSettings({
    ...cur,
    baseUrl: obState.baseUrl,
    apiKey: obState.apiKey,
    model: obState.model,
  });
  currentSettings = await getSettings();
  renderPresets();
  fillForm(currentSettings);
  refreshStatus();
}

function escapeHtmlAttr(s) {
  if (!s) return '';
  return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

document.getElementById('obRestart').addEventListener('click', async () => {
  await setOnboardingDone(false);
  startOnboarding();
});

async function refreshStatus() {
  const configured = await isConfigured();
  // legacy static banner removed; status now surfaced via onboarding modal only
}

async function refreshProfileSelect() {
  const profiles = await listProfiles();
  const active = await getActiveProfile();
  const select = $('profileSelect');
  select.innerHTML = '';
  for (const p of profiles) {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    select.appendChild(opt);
  }
  select.value = active?.id || '';
}

async function reloadForProfileChange() {
  currentSettings = await getSettings();
  fillForm(currentSettings);
  highlightActivePreset();
  updateKeyHint();
  toggleKeyField();
  refreshStatus();
}

async function handleProfileSwitch() {
  const id = $('profileSelect').value;
  if (!id) return;
  await saveSettings({
    baseUrl: $('baseUrl').value.trim(),
    apiKey: $('apiKey').value.trim(),
    model: ($('modelSelect').value === '__custom__' ? $('modelInput').value.trim() : $('modelSelect').value),
    systemPrompt: $('systemPrompt').value,
    temperature: parseFloat($('temperature').value) || 0,
    translateTarget: $('translateTarget').value === '__custom__' ? $('translateTargetInput').value.trim() : $('translateTarget').value,
  });
  await switchProfile(id);
  await reloadForProfileChange();
}

async function handleProfileNew() {
  const name = prompt(t('promptProfileName'), t('profileDefaultName', [(await listProfiles()).length + 1]));
  if (name === null) return;
  await createProfile(name.trim() || t('profileNewFallback'));
  await refreshProfileSelect();
  await reloadForProfileChange();
}

async function handleProfileRename() {
  const id = $('profileSelect').value;
  const active = await getActiveProfile();
  if (!id || !active) return;
  const name = prompt(t('promptRenameProfile'), active.name);
  if (name === null) return;
  await renameProfile(id, name.trim() || active.name);
  await refreshProfileSelect();
}

async function handleProfileDelete() {
  const id = $('profileSelect').value;
  if (!id) return;
  if (!confirm(t('confirmDeleteProfile'))) return;
  const ok = await deleteProfile(id);
  if (ok) {
    await refreshProfileSelect();
    await reloadForProfileChange();
  } else {
    alert(t('errMinOneProfile'));
  }
}

function renderPresets() {
  const grid = $('presetGrid');
  grid.innerHTML = '';
  for (const preset of PROVIDER_PRESETS) {
    const card = document.createElement('button');
    card.className = 'preset-card';
    if (!preset.needsKey) card.classList.add('no-key');
    card.dataset.presetId = preset.id;

    const nameRow = document.createElement('span');
    nameRow.className = 'pc-name-row';
    if (preset.color) {
      const dot = document.createElement('span');
      dot.className = 'pc-dot';
      dot.style.background = preset.color;
      dot.style.boxShadow = `0 0 0 2px ${preset.color}22`;
      nameRow.appendChild(dot);
    }
    const name = document.createElement('span');
    name.className = 'pc-name';
    name.textContent = preset.name;
    nameRow.appendChild(name);

    const desc = document.createElement('span');
    desc.className = 'pc-desc';
    if (preset.id === 'custom') desc.textContent = t('customPresetDesc');
    else if (preset.id === 'openrouter') desc.textContent = t('openrouterDesc');
    else desc.textContent = (preset.models[0] || '');

    card.append(nameRow, desc);
    grid.appendChild(card);
  }
  highlightActivePreset();
}

function highlightActivePreset() {
  const preset = findPreset(currentSettings.baseUrl);
  document.querySelectorAll('.preset-card').forEach((card) => {
    card.classList.toggle('active', card.dataset.presetId === preset.id);
  });
}

function fillForm(s) {
  $('baseUrl').value = s.baseUrl || '';
  $('apiKey').value = s.apiKey || '';
  $('systemPrompt').value = s.systemPrompt || '';
  $('temperature').value = s.temperature ?? 0.7;
  $('tempVal').textContent = s.temperature ?? 0.7;
  updateModelSelect(s);
  updateKeyHint();
  toggleKeyField();
  updateTranslateTarget(s);
}

function updateTranslateTarget(s) {
  const select = $('translateTarget');
  const input = $('translateTargetInput');
  const val = s.translateTarget || t('langZh');
  const opts = Array.from(select.options).map((o) => o.value);
  if (opts.includes(val)) {
    select.value = val;
    input.classList.add('hidden');
  } else {
    select.value = '__custom__';
    input.value = val;
    input.classList.remove('hidden');
  }
}

function updateModelSelect(s, apiModels) {
  const preset = findPreset(s.baseUrl);
  const select = $('modelSelect');
  const input = $('modelInput');
  select.innerHTML = '';

  const presetModels = preset.models.length > 0 ? preset.models : [];
  const merged = [...new Set([...presetModels, ...(apiModels || [])])];
  if (merged.length > 0 && !merged.includes('__custom__')) {
    for (const m of merged) {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      select.appendChild(opt);
    }
  }

  const customOpt = document.createElement('option');
  customOpt.value = '__custom__';
  customOpt.textContent = t('customOption');
  select.appendChild(customOpt);

  if (merged.includes(s.model)) {
    select.value = s.model;
    input.classList.add('hidden');
  } else {
    select.value = '__custom__';
    input.value = s.model || '';
    input.classList.remove('hidden');
  }
}

async function handleModelFetch() {
  const btn = $('modelFetch');
  const status = $('modelFetchStatus');
  const baseUrl = $('baseUrl').value.trim();
  const apiKey = $('apiKey').value.trim();
  if (!baseUrl || !apiKey) {
    status.textContent = t('errFillBaseKey');
    return;
  }
  btn.disabled = true;
  const original = btn.textContent;
  btn.textContent = t('fetchingModels');
  status.textContent = '';
  try {
    const models = await fetchModels({ baseUrl, apiKey });
    if (models.length === 0) {
      status.textContent = t('errNoModels');
      return;
    }
    currentSettings = { ...currentSettings, baseUrl, apiKey };
    updateModelSelect({ ...currentSettings, baseUrl }, models);
    status.textContent = t('modelsFound', [models.length]);
  } catch (err) {
    status.textContent = `✕ ${formatError(err)}`;
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
}

function updateKeyHint() {
  const preset = findPreset(currentSettings.baseUrl);
  const link = $('keyLink');
  link.innerHTML = '';

  if (preset.keyHintKey) {
    const hint = document.createElement('span');
    hint.textContent = chrome.i18n.getMessage(preset.keyHintKey) || '';
    link.appendChild(hint);
  }
  if (preset.keyUrl) {
    const sep = document.createElement('span');
    sep.textContent = '·';
    link.appendChild(sep);
    const a = document.createElement('a');
    a.href = preset.keyUrl;
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = t('getKeyLink');
    link.appendChild(a);
  }
}

function toggleKeyField() {
  const preset = findPreset(currentSettings.baseUrl);
  $('keyField').classList.toggle('hidden', !preset.needsKey);
}

function autoSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const baseUrl = $('baseUrl').value.trim();
    const apiKey = $('apiKey').value.trim();
    const modelSelect = $('modelSelect').value;
    const model = modelSelect === '__custom__' ? $('modelInput').value.trim() : modelSelect;
    const systemPrompt = $('systemPrompt').value;
    const temperature = parseFloat($('temperature').value) || 0;
    const ttSelect = $('translateTarget').value;
    const translateTarget = ttSelect === '__custom__' ? $('translateTargetInput').value.trim() : ttSelect;

    currentSettings = await saveSettings({ baseUrl, apiKey, model, systemPrompt, temperature, translateTarget });
    highlightActivePreset();
    const ind = $('autoSaved');
    ind.classList.add('show');
    setTimeout(() => ind.classList.remove('show'), 1500);
  }, 500);
}

function applyPreset(preset) {
  currentSettings = { ...currentSettings, baseUrl: preset.baseUrl, model: preset.model };
  saveSettings({ baseUrl: preset.baseUrl, model: preset.model });
  $('baseUrl').value = preset.baseUrl;
  updateModelSelect(currentSettings);
  updateKeyHint();
  toggleKeyField();
  highlightActivePreset();
  autoSave();
}

function bindEvents() {
  $('profileSelect').addEventListener('change', handleProfileSwitch);
  $('profileNew').addEventListener('click', handleProfileNew);
  $('profileRename').addEventListener('click', handleProfileRename);
  $('profileDelete').addEventListener('click', handleProfileDelete);

  $('presetGrid').addEventListener('click', (e) => {
    const card = e.target.closest('.preset-card');
    if (!card) return;
    const preset = PROVIDER_PRESETS.find((p) => p.id === card.dataset.presetId);
    if (preset) applyPreset(preset);
  });

  $('baseUrl').addEventListener('input', () => {
    autoSave();
    setTimeout(() => {
      highlightActivePreset();
      updateModelSelect(currentSettings);
      updateKeyHint();
      toggleKeyField();
    }, 600);
  });

  $('apiKey').addEventListener('input', autoSave);

  $('modelSelect').addEventListener('change', () => {
    if ($('modelSelect').value === '__custom__') {
      $('modelInput').classList.remove('hidden');
      $('modelInput').focus();
    } else {
      $('modelInput').classList.add('hidden');
      autoSave();
    }
  });
  $('modelInput').addEventListener('input', autoSave);
  $('modelFetch').addEventListener('click', handleModelFetch);

  $('systemPrompt').addEventListener('input', autoSave);

  $('translateTarget').addEventListener('change', () => {
    if ($('translateTarget').value === '__custom__') {
      $('translateTargetInput').classList.remove('hidden');
      $('translateTargetInput').focus();
    } else {
      $('translateTargetInput').classList.add('hidden');
      autoSave();
    }
  });
  $('translateTargetInput').addEventListener('input', autoSave);

  $('temperature').addEventListener('input', () => {
    $('tempVal').textContent = $('temperature').value;
    autoSave();
  });

  $('toggleKey').addEventListener('click', () => {
    const input = $('apiKey');
    const btn = $('toggleKey');
    if (input.type === 'password') {
      input.type = 'text';
      btn.textContent = t('hideKey');
    } else {
      input.type = 'password';
      btn.textContent = t('showKey');
    }
  });

  $('btnTest').addEventListener('click', runTest);
}

async function runTest() {
  const btn = $('btnTest');
  const dot = $('connStatus');
  const status = $('status');

  btn.disabled = true;
  btn.setAttribute('aria-busy', 'true');
  btn.innerHTML = `<span class="spinner"></span>${t('testing')}`;
  dot.className = 'status-dot testing';
  status.className = 'status info';
  status.textContent = t('connecting');

  try {
    const settings = await getSettings();
    const data = await testConnection(settings);
    const count = data.data?.length ?? '?';
    dot.className = 'status-dot ok';
    status.className = 'status ok';
    status.textContent = t('connSuccess', [count]);
  } catch (err) {
    dot.className = 'status-dot err';
    status.className = 'status err';
    status.textContent = `✕ ${formatError(err)}`;
  } finally {
    btn.disabled = false;
    btn.removeAttribute('aria-busy');
    btn.textContent = t('testConnection');
  }
}

init();
