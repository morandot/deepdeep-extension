import { getSettings, saveSettings, PROVIDER_PRESETS, findPreset, listProfiles, getActiveProfile, switchProfile, createProfile, renameProfile, deleteProfile } from '../lib/storage.js';
import { testConnection, fetchModels, formatError } from '../lib/api.js';

const $ = (id) => document.getElementById(id);

let currentSettings = {};
let saveTimer = null;

async function init() {
  await refreshProfileSelect();
  currentSettings = await getSettings();
  renderPresets();
  fillForm(currentSettings);
  bindEvents();
}

async function refreshProfileSelect() {
  const profiles = await listProfiles();
  const active = await getActiveProfile();
  const select = $('profileSelect');
  select.innerHTML = '';
  for (const p of profiles) {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    select.appendChild(opt);
  }
  select.value = active?.id || '';
}

async function reloadForProfileChange() {
  currentSettings = await getSettings();
  fillForm(currentSettings);
  highlightActivePreset();
  updateKeyHint();
  toggleKeyField();
}

async function handleProfileSwitch() {
  const id = $('profileSelect').value;
  if (!id) return;
  await saveSettings({
    baseUrl: $('baseUrl').value.trim(),
    apiKey: $('apiKey').value.trim(),
    model: ($('modelSelect').value === '__custom__' ? $('modelInput').value.trim() : $('modelSelect').value),
    systemPrompt: $('systemPrompt').value,
    temperature: parseFloat($('temperature').value) || 0,
    translateTarget: $('translateTarget').value === '__custom__' ? $('translateTargetInput').value.trim() : $('translateTarget').value,
  });
  await switchProfile(id);
  await reloadForProfileChange();
}

async function handleProfileNew() {
  const name = prompt('新配置方案名称：', `方案 ${(await listProfiles()).length + 1}`);
  if (name === null) return;
  await createProfile(name.trim() || '新方案');
  await refreshProfileSelect();
  await reloadForProfileChange();
}

async function handleProfileRename() {
  const id = $('profileSelect').value;
  const active = await getActiveProfile();
  if (!id || !active) return;
  const name = prompt('重命名配置方案：', active.name);
  if (name === null) return;
  await renameProfile(id, name.trim() || active.name);
  await refreshProfileSelect();
}

async function handleProfileDelete() {
  const id = $('profileSelect').value;
  if (!id) return;
  if (!confirm('删除该配置方案？此操作不可撤销。')) return;
  const ok = await deleteProfile(id);
  if (ok) {
    await refreshProfileSelect();
    await reloadForProfileChange();
  } else {
    alert('至少保留一个配置方案');
  }
}

function renderPresets() {
  const grid = $('presetGrid');
  grid.innerHTML = '';
  for (const preset of PROVIDER_PRESETS) {
    const card = document.createElement('button');
    card.className = 'preset-card';
    if (!preset.needsKey) card.classList.add('no-key');
    card.dataset.presetId = preset.id;

    const name = document.createElement('span');
    name.className = 'pc-name';
    name.textContent = preset.name;

    const desc = document.createElement('span');
    desc.className = 'pc-desc';
    desc.textContent = preset.id === 'custom' ? '任意兼容 API' : (preset.models[0] || '');

    card.append(name, desc);
    grid.appendChild(card);
  }
  highlightActivePreset();
}

function highlightActivePreset() {
  const preset = findPreset(currentSettings.baseUrl);
  document.querySelectorAll('.preset-card').forEach((card) => {
    card.classList.toggle('active', card.dataset.presetId === preset.id);
  });
}

function fillForm(s) {
  $('baseUrl').value = s.baseUrl || '';
  $('apiKey').value = s.apiKey || '';
  $('systemPrompt').value = s.systemPrompt || '';
  $('temperature').value = s.temperature ?? 0.7;
  $('tempVal').textContent = s.temperature ?? 0.7;
  updateModelSelect(s);
  updateKeyHint();
  toggleKeyField();
  updateTranslateTarget(s);
}

function updateTranslateTarget(s) {
  const select = $('translateTarget');
  const input = $('translateTargetInput');
  const val = s.translateTarget || '中文';
  const opts = Array.from(select.options).map((o) => o.value);
  if (opts.includes(val)) {
    select.value = val;
    input.classList.add('hidden');
  } else {
    select.value = '__custom__';
    input.value = val;
    input.classList.remove('hidden');
  }
}

function updateModelSelect(s, apiModels) {
  const preset = findPreset(s.baseUrl);
  const select = $('modelSelect');
  const input = $('modelInput');
  select.innerHTML = '';

  const presetModels = preset.models.length > 0 ? preset.models : [];
  const merged = [...new Set([...presetModels, ...(apiModels || [])])];
  if (merged.length > 0 && !merged.includes('__custom__')) {
    for (const m of merged) {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      select.appendChild(opt);
    }
  }

  const customOpt = document.createElement('option');
  customOpt.value = '__custom__';
  customOpt.textContent = '✏️ 自定义...';
  select.appendChild(customOpt);

  if (merged.includes(s.model)) {
    select.value = s.model;
    input.classList.add('hidden');
  } else {
    select.value = '__custom__';
    input.value = s.model || '';
    input.classList.remove('hidden');
  }
}

async function handleModelFetch() {
  const btn = $('modelFetch');
  const status = $('modelFetchStatus');
  const baseUrl = $('baseUrl').value.trim();
  const apiKey = $('apiKey').value.trim();
  if (!baseUrl || !apiKey) {
    status.textContent = '请先填写 Base URL 和 API Key';
    return;
  }
  btn.disabled = true;
  const original = btn.textContent;
  btn.textContent = '查询中…';
  status.textContent = '';
  try {
    const models = await fetchModels({ baseUrl, apiKey });
    if (models.length === 0) {
      status.textContent = '⚠️ 接口未返回模型列表';
      return;
    }
    currentSettings = { ...currentSettings, baseUrl, apiKey };
    updateModelSelect({ ...currentSettings, baseUrl }, models);
    status.textContent = `✓ 查询到 ${models.length} 个模型`;
  } catch (err) {
    status.textContent = `✕ ${formatError(err)}`;
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
}

function updateKeyHint() {
  const preset = findPreset(currentSettings.baseUrl);
  const link = $('keyLink');
  link.innerHTML = '';

  if (preset.keyHint) {
    const hint = document.createElement('span');
    hint.textContent = preset.keyHint;
    link.appendChild(hint);
  }
  if (preset.keyUrl) {
    const sep = document.createElement('span');
    sep.textContent = '·';
    link.appendChild(sep);
    const a = document.createElement('a');
    a.href = preset.keyUrl;
    a.target = '_blank';
    a.rel = 'noopener';
    a.textContent = '获取 Key →';
    link.appendChild(a);
  }
}

function toggleKeyField() {
  const preset = findPreset(currentSettings.baseUrl);
  $('keyField').classList.toggle('hidden', !preset.needsKey);
}

function autoSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const baseUrl = $('baseUrl').value.trim();
    const apiKey = $('apiKey').value.trim();
    const modelSelect = $('modelSelect').value;
    const model = modelSelect === '__custom__' ? $('modelInput').value.trim() : modelSelect;
    const systemPrompt = $('systemPrompt').value;
    const temperature = parseFloat($('temperature').value) || 0;
    const ttSelect = $('translateTarget').value;
    const translateTarget = ttSelect === '__custom__' ? $('translateTargetInput').value.trim() : ttSelect;

    currentSettings = await saveSettings({ baseUrl, apiKey, model, systemPrompt, temperature, translateTarget });
    highlightActivePreset();
    const ind = $('autoSaved');
    ind.classList.add('show');
    setTimeout(() => ind.classList.remove('show'), 1500);
  }, 500);
}

function applyPreset(preset) {
  currentSettings = { ...currentSettings, baseUrl: preset.baseUrl, model: preset.model };
  saveSettings({ baseUrl: preset.baseUrl, model: preset.model });
  $('baseUrl').value = preset.baseUrl;
  updateModelSelect(currentSettings);
  updateKeyHint();
  toggleKeyField();
  highlightActivePreset();
  autoSave();
}

function bindEvents() {
  $('profileSelect').addEventListener('change', handleProfileSwitch);
  $('profileNew').addEventListener('click', handleProfileNew);
  $('profileRename').addEventListener('click', handleProfileRename);
  $('profileDelete').addEventListener('click', handleProfileDelete);

  $('presetGrid').addEventListener('click', (e) => {
    const card = e.target.closest('.preset-card');
    if (!card) return;
    const preset = PROVIDER_PRESETS.find((p) => p.id === card.dataset.presetId);
    if (preset) applyPreset(preset);
  });

  $('baseUrl').addEventListener('input', () => {
    autoSave();
    setTimeout(() => {
      highlightActivePreset();
      updateModelSelect(currentSettings);
      updateKeyHint();
      toggleKeyField();
    }, 600);
  });

  $('apiKey').addEventListener('input', autoSave);

  $('modelSelect').addEventListener('change', () => {
    if ($('modelSelect').value === '__custom__') {
      $('modelInput').classList.remove('hidden');
      $('modelInput').focus();
    } else {
      $('modelInput').classList.add('hidden');
      autoSave();
    }
  });
  $('modelInput').addEventListener('input', autoSave);
  $('modelFetch').addEventListener('click', handleModelFetch);

  $('systemPrompt').addEventListener('input', autoSave);

  $('translateTarget').addEventListener('change', () => {
    if ($('translateTarget').value === '__custom__') {
      $('translateTargetInput').classList.remove('hidden');
      $('translateTargetInput').focus();
    } else {
      $('translateTargetInput').classList.add('hidden');
      autoSave();
    }
  });
  $('translateTargetInput').addEventListener('input', autoSave);

  $('temperature').addEventListener('input', () => {
    $('tempVal').textContent = $('temperature').value;
    autoSave();
  });

  $('toggleKey').addEventListener('click', () => {
    const input = $('apiKey');
    const btn = $('toggleKey');
    if (input.type === 'password') {
      input.type = 'text';
      btn.textContent = '隐藏';
    } else {
      input.type = 'password';
      btn.textContent = '显示';
    }
  });

  $('btnTest').addEventListener('click', runTest);
}

async function runTest() {
  const btn = $('btnTest');
  const dot = $('connStatus');
  const status = $('status');

  btn.disabled = true;
  btn.textContent = '测试中...';
  dot.className = 'status-dot testing';
  status.className = 'status info';
  status.textContent = '正在连接...';

  try {
    const settings = await getSettings();
    const data = await testConnection(settings);
    const count = data.data?.length ?? '?';
    dot.className = 'status-dot ok';
    status.className = 'status ok';
    status.textContent = `✓ 连接成功（${count} 个模型可用）`;
  } catch (err) {
    dot.className = 'status-dot err';
    status.className = 'status err';
    status.textContent = `✕ ${formatError(err)}`;
  } finally {
    btn.disabled = false;
    btn.textContent = '测试连接';
  }
}

init();
