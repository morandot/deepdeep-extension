# Deepdeep

划词问答 + 侧边栏对话 Chrome/Edge 扩展（Manifest V3，零依赖，无构建步骤）。

- **BYOK**：自带 API Key，直连任意 OpenAI 兼容端点（DeepSeek / MiMo / OpenAI / Anthropic / OpenRouter）
- **划词浮窗**：选中文字即弹工具栏（问 Deepdeep / 解释 / 翻译 / 总结），Shadow DOM 隔离页面样式
- **侧边栏对话**：`@` 引用标签页作为上下文、联网搜索开关、历史会话切换、Markdown 导出
- **看图**：右键图片或选中页面图片，支持视觉模型直接分析（gpt-4o / Claude / Qwen-VL 等）
- **多配置方案**：保存多套 API 配置随时切换

## 开发

```bash
# 无构建步骤，直接加载
# chrome://extensions → 开发者模式 → 加载已解压的扩展程序 → 选择本项目目录
```

## Logo 使用规则

品牌色：`#4D6BFE`（深色模式 `#6B83FE`）。源文件在 `icons/`：

- `logo-badge.svg` — 主标记（蓝徽章 + 挖空 D），用于 favicon、头像、方形/圆形场景
- `logo-mark.svg` — 副标记（纯 D 实体），用于页眉、文档抬头

规则：

- 最小使用尺寸 **16px**，更小不要用
- 徽章四周留白至少为**直径的 25%**
- 只允许这两个变体：**不要拉伸、不要加描边、不要加阴影、不要改 D 的弧度**
- 深色背景上徽章仍用 `#4D6BFE`；需要单色时整体用纯白或纯黑
- 组件内联 SVG 用 `fill="currentColor"`，默认色走 CSS 变量 `--brand: #4D6BFE`（见 `lib/logo.js`）
- 光栅化 PNG（icon/favicon/apple-touch）由 `rsvg-convert` 从 SVG 生成，改源文件后需重新生成

## 隐私

见 [PRIVACY.md](PRIVACY.md)（托管于 https://deepdeep.nopress.net/privacy ）。
